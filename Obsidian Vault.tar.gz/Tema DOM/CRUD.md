|**CRUD**|**JavaScript (DOM & CSS)**|
|---|---|
|**C**reate|DOM: `createElement()`: Creas el nodo en memoria, pero está "huérfano" hasta que usas `append()`, `appendChild()`.<br>`innerHTML`: Remplaza todo el contenido. El hermano mayor [[insertAdjacentHTML]] <br><br>CSS: `.classList.add()` Añade sin romper nada. `.className` Machaca todo lo anterior.|
|**R**ead|DOM: `querySelector()`, `getElementById()`, `getAttribute()`, `textContent`<br><br>CSS: `.classList.contains()` Responde con un true o bien false.<br>`.style` ejemplo: `nodo.style.color;`, `nodo.style.fontSize;`.|
|**U**pdate|DOM: `style.property`, `setAttribute()`, `.value` (en inputs).<br>`.replaceChild(new, old)` Reemplaza un nodo hijo existente por uno nuevo<br><br>CSS: `.toggle` Prende/Apaga. `classList.toggle('azul');`<br>`nodo.style.cssText = 'color: blue; font-size: 100px;';`|
|**D**elete|DOM:`element.remove()` se elimine a sí mismo,<br>`removeChild(childNode)` Elimina un nodo hijo del DOM..|