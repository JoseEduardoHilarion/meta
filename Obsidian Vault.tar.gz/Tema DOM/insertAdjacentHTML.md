Este es el "hermano mayor" de `innerHTML`. En lugar de borrar todo el contenido y escribirlo de nuevo (lo cual es lento), este método te permite **insertar** código nuevo en una posición específica.

- `'beforebegin'`: Antes del elemento.
    
- `'afterbegin'`: Dentro, antes del primer hijo.
    
- `'beforeend'`: Dentro, después del último hijo (el favorito para listas).
    
- `'afterend'`: Después del elemento.
    

```JavaScript
const lista = document.querySelector('#miLista');
lista.insertAdjacentHTML('beforeend', '<li>Nuevo Item</li>'); 
// ¡No borra los anteriores! Solo agrega al final.
```