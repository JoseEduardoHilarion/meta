- **moverse** a través del árbol de nodos para encontrar, seleccionar o modificar elementos basándose en su relación con otros (padres, hijos o hermanos).

|**Propiedad**|**Descripción**|
|---|---|
|Ir al Padre |`.parentElement`|
|Buscar ARRIBA el primer ancestro|`.closest('.clase')`|
|Primer Hijo y Último|`.firstElementChild` y `.lastElementChild`|
|Ir a los elementos de adentro|`.childNodes`y `.children` / `.querySelector()`|
|Hermano Anterior y Siguiente|`previousElementSibling` y `nextElementSibling`|


---