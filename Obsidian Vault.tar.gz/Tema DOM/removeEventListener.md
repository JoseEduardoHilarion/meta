Le dices al navegador: **Ya no me interesa este evento**. No puedes remover funciones anonimas.


### Ejemplo practico: un boton que solo funciona una vez
```JavaScript
function hacerCompra() {
	console.log('Compra realizada!')
	this.removeEventListener('click', hacerCompra) // this = el boton
	this.textContent = 'Ya compraste'
	this.disabled = true
}
boton.addEventListener('click', hacerCompra)
```

```JavaScript
function hacerCompra(event) {
	console.log('Compra realizada!')
	event.currentTarget.removeEventListener('click', hacerCompra)
	event.currentTarget.textContent = 'Ya compraste'
	event.currentTarget.disabled = true
}
boton.addEventListener('click', hacerCompra)
```

```JavaScript
boton.addEventListener('click', function() {
	console.log('Esto solo pasa una vez')
}, { once: true }) // Se remueve automaticamente despues del primer disparo
```

---