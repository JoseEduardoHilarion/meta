El navegador convierte el HTML en una **estructura de árbol de objetos** que JavaScript puede leer y modificar en tiempo real. Cada etiqueta HTML se convierte en un **nodo**.

> [!tip]
> Si usás librerías como React o Vue, **no uses estos métodos directamente**; manipulá el estado de tu framework en su lugar. El framework se encarga del DOM.

![[significado DOM]]
![[Targetear (referenciar)]]
![[Travear (subir o bajar)]]
![[CRUD]]
![[mini-React]]
![[Eventos]]
![[MOTOR]]