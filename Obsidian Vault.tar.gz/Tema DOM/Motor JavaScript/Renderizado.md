- Primero ejecuta los **[[requestAnimationFrame]] (rAF)**.    
- Luego hace el _Style_ (CSS), el _Layout_ (Geometría) y el _Paint_ (Pintar píxeles).

[[Event Loop]]