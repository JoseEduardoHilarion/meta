La cola de tareas "comunes". Aquí llegan las callbacks una vez que las [[Web APIs]] terminan su trabajo.

## Qué entra acá:
- [[setTimeout]] y `setInterval`
- Eventos del DOM: `click`, `scroll`, `keydown`...
- Interrupciones de I/O (lectura de archivos en Node)
- `MessageChannel`

## Regla clave:
El [[Event Loop]] ejecuta **una sola macrotask por vuelta**. Después de cada una, vuelve a vaciar la [[Microtask Queue]] antes de tomar la siguiente.

> Esto significa que si tenés 100 `setTimeout(..., 0)` encolados, se ejecutarán de a uno por vuelta, dándole al navegador la oportunidad de renderizar entre medio.

## Diferencia con Microtasks:
| | [[Microtask Queue]] | Macrotask Queue |
|---|---|---|
| Ejemplos | Promesas, `queueMicrotask` | `setTimeout`, eventos DOM |
| Por vuelta | **Todas** | **Una sola** |
| Prioridad | Mayor | Menor |

---
