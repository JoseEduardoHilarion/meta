## `setTimeout(procesarSiguiente, 0)`
La función procesarSiguiente **sale del [[Call Stack]]** y va al **[[Web API]]**. Luego el Runtime de JS como esta a 0, la saca del **[[Web API]]** y lo coloca al final de  **[[Macrotasks Callback Queue]]**.

```JavaScript
const listaGigante = new Array(100000).fill("Dato pesado");
function procesarConTimeout(array) {
  let indice = 0;
  const tamañoTrozo = 500; // Procesamos de 500 en 500
  function procesarSiguiente() {
    const fin = Math.min(indice + tamañoTrozo, array.length);    
    // Procesamos el trozo actual
    for (let i = indice; i < fin; i++) {
      // Simulación de cálculo pesado
      const item = array[i]; 
    }
    indice = fin;
    console.log(`Procesado hasta: ${indice}`);
    if (indice < array.length) {
      // Agendamos el siguiente trozo como una [[Macrotasks Callback Queue]]
      setTimeout(procesarSiguiente, 0); 
    } else {
      console.log("¡Fin del procesamiento con Timeout!");
    }
  }
  procesarSiguiente();
}
```
