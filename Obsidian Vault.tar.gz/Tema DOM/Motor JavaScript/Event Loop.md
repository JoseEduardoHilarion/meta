El **vigilante** del motor. Su trabajo es simple: mirar constantemente si el [[Call Stack]] está vacío. Cuando lo está, toma la siguiente tarea pendiente y la empuja al stack para que se ejecute.

> Sin el Event Loop, la asincronía no existiría: el motor ejecutaría solo código sincrónico y se bloquearía para siempre ante cualquier espera.

## Orden de prioridad en cada vuelta:
1. Vacía toda la [[Microtask Queue]] (comportamiento voraz).
2. Ejecuta una tarea de [[Tema DOM/Motor JavaScript/Renderizado]] si corresponde.
3. Ejecuta **una** sola tarea de [[Macrotasks Callback Queue]].
4. Vuelve al paso 1.

## ¿Dónde vive?
El motor no corre solo; vive dentro de un entorno (Navegador/Node) que le da superpoderes asíncronos a través de las [[Web APIs]].

---
