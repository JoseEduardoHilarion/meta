## Prioridad de Ejecución:

El [[Event Loop]] respeta siempre este orden. Las colas **2, 3 y 4 solo se procesan cuando el [[Call Stack]] está completamente vacío**.

1. **[[Call Stack]] (Sincrónico):** se ejecuta todo el código directo, función por función.
2. **[[Microtask Queue]] (Cola VIP):** se vacía *entera* antes de continuar. Ninguna otra tarea puede interrumpirla.
3. **[[Tema DOM/Motor JavaScript/Renderizado]]:** solo ocurre si el navegador lo considera necesario (~60fps). Incluye `rAF` → Style → Layout → Paint.
4. **[[Macrotasks Callback Queue]]:** se ejecuta **una sola tarea** por vuelta del loop, luego vuelve al paso 2.

> **Regla de oro:** si querés que algo ocurra *antes* del renderizado, usá Promesas. Si querés que ocurra *después* sin bloquear la pantalla, usá `setTimeout`.

---
