**Dividir** un proceso pesado (ej. un bucle gigante) usando `setTimeout` o `requestAnimationFrame`.
 - _Objetivo:_ Liberar la [[Call Stack]] para que el usuario no sienta el sistema "congelado" (evitar la inanición de procesos).
![[setTimeout]]
![[requestAnimationFrame]]

---