APIs del **navegador** (o de Node) que corren *fuera* del motor JS, en hilos separados. Esto es lo que hace posible la asincronía: el motor delega la tarea pesada a la Web API y sigue ejecutando código sin bloquearse.

## Flujo:
`Call Stack` → delega a **Web API** → cuando termina, el resultado va a la cola correspondiente ([[Microtask Queue]] o [[Macrotasks Callback Queue]]) → el [[Event Loop]] lo devuelve al [[Call Stack]].

## Ejemplos:
- `document.querySelector()` — manipulación del DOM
- `addEventListener()` — eventos del usuario (click, scroll...)
- `fetch()` — peticiones de red (HTTP)
- `localStorage` — almacenamiento local
- `performance.now()` — temporizador de alta precisión
- `setTimeout` / `setInterval` — temporizadores
- `requestAnimationFrame` — sincronizado con el refresco de pantalla

---
