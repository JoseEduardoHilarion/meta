Un **documento virtual** (en memoria) donde podés construir nodos del DOM sin tocar el DOM real. Solo cuando está todo listo se inserta de un solo golpe.

> Cada vez que modificás el DOM directamente, el navegador puede disparar un **reflow** (recalcula geometría) y un **repaint** (redibuja píxeles). Con `DocumentFragment` eso ocurre **una sola vez**.

## Ejemplo:
```javascript
const lista = document.getElementById("mi-lista");
const fragmento = document.createDocumentFragment();

const datos = ["Manzana", "Banana", "Naranja"];
datos.forEach(texto => {
  const li = document.createElement("li");
  li.textContent = texto;
  fragmento.appendChild(li); // Se agrega al fragmento, NO al DOM real
});

lista.appendChild(fragmento); // Un solo reflow/repaint aquí
```

## Sin DocumentFragment (malo):
```javascript
datos.forEach(texto => {
  const li = document.createElement("li");
  li.textContent = texto;
  lista.appendChild(li); // Reflow/repaint por cada elemento ❌
});
```

Relacionado con [[Tema DOM/Motor JavaScript/Renderizado]] y [[Chunking]].

---
