## El Motor de JavaScript (Single Thread)
## Stack
![[Call Stack]]
### Queue
1. ![[Microtask Queue]]
2. ![[Tema DOM/Motor JavaScript/Renderizado]]
3. ![[Macrotasks Callback Queue]]
## Web
![[Web APIs]]
## Loop
![[Event Loop]]
![[Diagrama Motor.png]]
![[Tema DOM/Motor JavaScript/Ciclo de Vida]]
![[Optimizacion]]
