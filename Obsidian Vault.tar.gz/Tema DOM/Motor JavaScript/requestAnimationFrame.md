## Sincronizado con el Refresco
La funcion **`frame(tiempoActual)`** sale de [[Call Stack]], y se coloca entre las [[Microtask Queue]] y las [[Macrotasks Callback Queue]] osea en el [[Tema DOM/Motor JavaScript/Renderizado]].

```JavaScript
function procesarConRAF(array) {
  let indice = 0;
  function frame(tiempoActual) {
    const comienzo = performance.now();
    const presupuestoMs = 8; // Solo usamos 8ms de los 16ms disponibles para no laguear
    // Mientras tengamos tiempo en este frame y queden elementos...
    while (performance.now() - comienzo < presupuestoMs && indice < array.length) {
      // Tarea pesada
      const item = array[indice];
      indice++;
    }
    if (indice < array.length) {
      // Pedimos el próximo cuadro de animación disponible
      requestAnimationFrame(frame);
    } else {
      console.log("¡Fin del procesamiento con rAF!");
    }
  }
  requestAnimationFrame(frame);
}
```

## requestIdleCallback + Deadline

```JavaScript
const datosPesados = new Array(100000).fill(0).map((_, i) => i);
function procesadorPro(array) {
  let indice = 0;
  function procesar(deadline) {
    // deadline.timeRemaining() nos dice EXACTO cuántos milisegundos 
    // le quedan al navegador antes de tener que hacer otra tarea.
    // Es dinámico: si el monitor es de 144Hz, te dará menos tiempo.    
    while (indice < array.length && deadline.timeRemaining() > 0) {
      // Ejecutamos el trabajo pesado aquí
      const item = array[indice];
      // (Tu lógica aquí...)      
      indice++;
    }
    if (indice < array.length) {
      // Si todavía faltan elementos, pedimos el próximo hueco libre
      window.requestIdleCallback(procesar);
    } else {
      console.log("Tarea completada con precisión de milisegundos.");
    }
  }
  // Arrancamos el proceso cuando el navegador esté libre
  window.requestIdleCallback(procesar);
}
procesadorPro(datosPesados);
```