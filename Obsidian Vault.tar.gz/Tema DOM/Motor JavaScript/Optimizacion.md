Dos estrategias principales para no bloquear la interfaz ni saturar el [[Tema DOM/Motor JavaScript/Renderizado]]:

## 1. [[DocumentFragment]]
Minimiza los **reflows** del DOM agrupando todas las modificaciones en un documento virtual antes de insertarlas de una sola vez en el DOM real.
→ Ideal cuando agregás **muchos nodos** al DOM.

## 2. [[Chunking]]
Divide tareas pesadas en trozos pequeños para liberar el [[Call Stack]] entre cada trozo y permitir que el navegador respire.
→ Ideal cuando procesás **grandes volúmenes de datos**.

| Técnica | Problema que resuelve | Herramienta |
|---|---|---|
| DocumentFragment | Demasiados reflows | DOM virtual |
| Chunking con setTimeout | UI congelada | [[Macrotasks Callback Queue]] |
| Chunking con rAF | UI congelada + animaciones | [[Tema DOM/Motor JavaScript/Renderizado]] |

---
