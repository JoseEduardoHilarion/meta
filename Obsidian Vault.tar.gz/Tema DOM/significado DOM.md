El navegador convierte HTML en una **estructura de árbol** donde cada elemento es un **nodo** que puedes manipular con JavaScript.

```JavaScript
Document (raíz)
├── html
    ├── head
    │   ├── title
    │   └── meta
    └── body
        ├── h1
        ├── p
        └── div
            ├── span
            └── img
```
            
## **¿En dónde se utiliza el DOM?**
1. **HTML**: El DOM proporciona una manera de acceder y modificar elementos de una página HTML de manera dinámica.
2. **JavaScript**: El DOM proporciona una manera de acceder y modificar elementos de una página web mediante JavaScript.
3. **jQuery**: jQuery es una biblioteca de JavaScript que proporciona una manera más fácil de trabajar con el DOM y crear aplicaciones web dinámicas.
4. **Angular**: Marco de desarrollo de aplicaciones web basado en JavaScript que utiliza el DOM para crear aplicaciones web escalables y sólidas.
5. **React**: Biblioteca de JavaScript para la creación de interfaces de usuario que utiliza el DOM para crear aplicaciones web de alta rendimiento y enriquecer la experiencia de usuario.
## **¿Cuales son las preguntas más comunes sobre el DOM ?**

1. ¿Qué es el **DOM** y para qué se utiliza? El DOM Wep API para documentos HTML y XML. Se utiliza para acceder y manipular elementos de un documento de manera dinámica, lo que permite crear aplicaciones web dinámicas y mejorar la usabilidad.
    
2. ¿Cómo se **accede a elementos** del DOM? `getElementById` y `getElementsByTagName`, o mediante el uso de selectores de CSS con `querySelector`. También se pueden acceder elementos utilizando la propiedad `children` o la propiedad `parentNode`.
    
3. ¿Cómo se **modifican elementos** del DOM? Propiedades especiales como `innerHTML` y `innerText`, o mediante el uso de métodos como `appendChild` y `removeChild`. También se pueden modificar elementos utilizando el objeto `style` para cambiar el estilo de un elemento.
    
4. ¿Qué es un **nodo** del DOM y cómo se utiliza? Los nodos del DOM incluyen elementos de HTML, atributos de elementos y texto. Los nodos del DOM se pueden utilizar para acceder y modificar elementos del documento de manera dinámica.
    
5. ¿Qué es un **árbol** del DOM y cómo se utiliza? Muestra cómo los elementos del documento están relacionados entre sí. El árbol del DOM se utiliza para acceder y modificar elementos del documento de manera eficiente y para determinar cómo se afectan los cambios en un elemento en otros elementos relacionados.

> [!TIP] 
> Evita la manipulación excesiva y constante del DOM. En su lugar, intenta agrupar tus cambios y hacerlos **todos a la vez**. Esto mejorará el rendimiento de tu código al reducir el coste computacional de la renderización constante del DOM.

---