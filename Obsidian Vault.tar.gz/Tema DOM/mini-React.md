```JavaScript
// 1. ESTADO: La única fuente de verdad
let perfiles = [
    { id: 1, nombre: "Gemini", descripcion: "IA Colaboradora" },
    { id: 2, nombre: "Usuario", descripcion: "Aprendiz de JS" }];
const contenedor = document.getElementById("contenedor-tarjetas");
const nombre = document.getElementById("nom");
const descripcion = document.getElementById("desc");
// 2. COMPONENTE: Cómo se ve una tarjeta
function Tarjeta(perfil) {
    return `
        <div class="card">
            <h3>${perfil.nombre}</h3>
            <p>${perfil.descripcion}</p>
            <button class="btn-edit" onclick="prepararEdicion(${perfil.id})">Editar</button>
            <button class="btn-delete" onclick="eliminarPerfil(${perfil.id})">Borrar</button>
        </div>
    `;
}
// 3. RENDER: Sincroniza el Estado con el DOM
function render() {
    // "Mapeamos" los datos al componente y los unimos en un solo string
    contenedor.innerHTML = perfiles.map(p => Tarjeta(p)).join('');
}
// 4. ACCIONES (CRUD)
function agregarPerfil() {
    if (nombre.value && descripcion.value) {
        perfiles.push({
            id: Date.now(), // Generamos un ID único basado en tiempo
            nombre: nombre.value,
            descripcion: descripcion.value
        });
        // Limpiar inputs y refrescar pantalla
        nombre.value = descripcion.value = "";
        render();
    } else
        alert("Llena los campos");
}
function eliminarPerfil(id) {
    // DELETE: Filtramos el estado
    perfiles = perfiles.filter(p => p.id !== id);
    render();
}
function prepararEdicion(id) {
    const perfil = perfiles.find(p => p.id === id); // READ
    const nuevoNombre = prompt("Nuevo nombre:", perfil.nombre);

    if (nuevoNombre && nuevoNombre !== perfil.nombre) {
        // UPDATE: Modificamos el objeto dentro del array
        perfil.nombre = nuevoNombre;
        render();
    }
}
// Inicializamos la pantalla por primera vez
render();
```


---