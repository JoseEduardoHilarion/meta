## event listener (escuchador de eventos)
```JavaScript
const boton = document.getElementById('miBoton');
//QUIEN.addEventListener('QUE', COMO_REACCIONAR)
boton.addEventListener('click', function() {
    alert('¡Has hecho click en el botón!');
});
```

---