## Evitar el comportamiento por defecto

Esto no es lo mismo que [[stopPropagation]], pero se confunden mucho. preventDefault **cancela lo que el navegador haria** normalmente:
```JavaScript
// Evitar que un enlace navegue a otra pagina
const enlace = document.querySelector('a')
enlace.addEventListener('click', function(event) {
    event.preventDefault()
    console.log('El enlace NO navego a ninguna parte')
})
// Evitar que un formulario se envie y recargue la pagina
const form = document.querySelector('form')
form.addEventListener('submit', function(event) {
    event.preventDefault()
    console.log('Formulario procesado sin recargar')
})
```

|Metodo|Que hace|
|---|---|
|stopPropagation()|Frena la burbuja, los padres no se enteran|
|preventDefault()|Cancela el comportamiento nativo del navegador|

Son independientes. Puedes usar uno, el otro, o ambos.

---