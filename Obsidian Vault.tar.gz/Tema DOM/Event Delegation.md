# Delegacion de Eventos

En vez de poner un listener en cada hijo, pones un solo listener en el padre. Como el evento [[burbujeo]] hacia arriba, el padre se entera de todo lo que pasa en sus hijos.
```html
<ul id="lista">
    <li>Estudiar JS <button class="borrar">X</button></li>
    <li>Practicar DOM <button class="borrar">X</button></li>
</ul>
<button id="agregar">Agregar tarea</button>
```

```JavaScript
const lista = document.getElementById('lista')
const btnAgregar = document.getElementById('agregar')
// Delegacion para los botones de borrar
lista.addEventListener('click', function(event) {
    if (event.target.classList.contains('borrar')) {
        event.target.parentElement.remove()  // Elimina el <li> padre del boton
    }
})
// Agregar nuevas tareas
btnAgregar.addEventListener('click', function() {
    const nueva = document.createElement('li')
    nueva.innerHTML = 'Nueva tarea <button class="borrar">X</button>'
    lista.appendChild(nueva)
    // El boton "X" ya funciona sin necesidad de agregarle listener!
})
```

Fijate que usamos classList.contains('borrar') en vez de tagName. Puedes verificar por:

|Metodo|Ejemplo|Cuando usarlo|
|---|---|---|
|event.target.tagName|=== 'LI'|Cuando filtras por tipo de elemento|
|event.target.classList.contains()|('borrar')|Cuando filtras por clase CSS|
|event.target.matches()|('.borrar')|Cuando filtras por cualquier selector CSS|

matches() es el mas flexible:

```JavaScript
lista.addEventListener('click', function(event) {
    if (event.target.matches('.borrar')) {
        event.target.parentElement.remove()
    }
})
```

# Un problema comun: que pasa si dentro del **li** hay mas HTML?

```html
<li>
    <span class="texto">Estudiar JS</span>
    <button class="borrar"><strong>X</strong></button>
</li>
```

Si el usuario hace clic en el X, event.target es el strong, no el button

tu condicion **`matches('.borrar')`** fallaria.

La solucion es **`closest()`**, que busca hacia arriba en el arbol:


```JavaScript
lista.addEventListener('click', function(event) {
    const botonBorrar = event.target.closest('.borrar')
    if (botonBorrar) {
        botonBorrar.parentElement.remove()
    }
})
```

**`closest('.borrar')`** dice: "Desde donde hice clic, busca hacia arriba hasta encontrar un elemento con clase borrar". Si lo encuentra, lo devuelve. Si no, devuelve null.

---
