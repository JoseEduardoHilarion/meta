Cuando ocurre un evento, JavaScript automaticamente crea un objeto **event** con informacion sobre lo que paso. Puedes recibirlo como parametro:

```JavaScript
titulo.addEventListener('click', function(event) {
    console.log(event.type)    // "click"
    console.log(event.target)  // El elemento exacto donde ocurrio el clic (puede ser un hijo)
    console.log(event.currentTarget) //El elemento que tiene el addEventListener (this)
    console.log(event.clientX) // posicion X del mouse
    console.log(event.clientY) // posicion Y del mouse
})
```

---
