```JavaScript
const elemento = document.getElementById('miId');
const parrafos = document.getElementsByTagName('p');
const elementos = document.getElementsByClassName('miClase');


// Selectores CSS modernos
const elemento = document.querySelector('#miId');
const elementos = document.querySelectorAll('.miClase');
```


[Mozilla DOM](https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model)

[whatwg DOM](https://dom.spec.whatwg.org/)

---