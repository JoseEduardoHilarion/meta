## Parar la Propagacion
```JavaScript
<div id="fondo-oscuro">
    <div id="menu">
        <button>Opcion 1</button>
        <button>Opcion 2</button>
    </div>
</div>
const fondo = document.getElementById('fondo-oscuro')
const menu = document.getElementById('menu')
fondo.addEventListener('click', function() {
    fondo.style.display = 'none'  // Cerrar al hacer clic fuera
})
menu.addEventListener('click', function(event) {
    event.stopPropagation()  // Que NO se cierre al hacer clic DENTRO del menu
})
```

Sin stopPropagation, al hacer clic en cualquier boton dentro del menu, el evento burbujearia hasta fondo-oscuro y lo cerraria. Con stopPropagation, los clics dentro del menu se quedan ahi.

---