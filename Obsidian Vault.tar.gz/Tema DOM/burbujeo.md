  ![[burbujeo.png]]
  
```JavaScript  
<div id="abuelo">
    <div id="padre">
        <button id="hijo">Haz clic</button>
    </div>
</div>

const abuelo = document.getElementById('abuelo')
const padre = document.getElementById('padre')
const hijo = document.getElementById('hijo')
abuelo.addEventListener('click', function() {
    console.log('Clic en ABUELO')})
padre.addEventListener('click', function() {
    console.log('Clic en PADRE')})
hijo.addEventListener('click', function() {
    console.log('Clic en HIJO')})
```

![[stopPropagation]]

---