## mas comunes

|Evento|Cuando se dispara|
|---|---|
|click|El usuario hace clic|
|dblclick|Doble clic|
|mouseover|El mouse pasa por encima|
|mouseout|El mouse sale del elemento|
|keydown|Se presiona una tecla|
|keyup|Se suelta una tecla|
|submit|Se envia un formulario|
|input|Se escribe en un campo|
|load|La pagina termina de cargar|
|scroll|El usuario hace scroll|
![[addEventListener]]
![[El objeto Event]]
![[burbujeo]]
![[preventDefault]]
![[removeEventListener]]
![[Event Delegation]]
![[defer]]

---