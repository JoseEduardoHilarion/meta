## Carga deferida

1. Descárgalo en segundo plano.
2. Ejecútalo al final.

## La Regla de Oro del Orden
```html
<script defer src="script1.js"></script>
<script defer src="script2.js"></script>
<script defer src="script3.js"></script>

```
Si tienes tres scripts con `defer`, se ejecutarán en el orden en que aparecen en el código


---