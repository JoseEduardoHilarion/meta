La diferencia es que hay que renderizarlo en un DOM simulado **`jsdom`** y verificar lo que aparece en pantalla con **`screen`**.

```jsx
import { describe, test, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Input } from '../components/form/Input';

describe('Input', () => {
  test('muestra el label', () => {
    render(
      <Input
        label="Describe tu meta"
        name="detalles"
        value=""
        onChange={() => {}}
      />
    );
    // busca el texto "Describe tu meta" en el DOM
    expect(screen.getByText('Describe tu meta')).toBeInTheDocument();
  });

  test('muestra el mensaje de error cuando existe', () => {
    render(
      <Input
        label="Describe tu meta"
        name="detalles"
        value=""
        onChange={() => {}}
        error="La descripción no puede estar vacía."
      />
    );
    expect(
      screen.getByText('La descripción no puede estar vacía.')
    ).toBeInTheDocument();
  });

  test('no muestra error cuando no existe', () => {
    render(
      <Input
        label="Describe tu meta"
        name="detalles"
        value=""
        onChange={() => {}}
      />
    );
    expect(
      screen.queryByText('La descripción no puede estar vacía.')
    ).not.toBeInTheDocument();
  });

  test('el input tiene el value correcto', () => {
    render(
      <Input
        label="Describe tu meta"
        name="detalles"
        value="Correr 5km"
        onChange={() => {}}
      />
    );
    const input = screen.getByRole('textbox');//busca por rol semántico
    expect(input).toHaveValue('Correr 5km');//verifica el valor de un input
  });

});
```
La diferencia clave es **`screen`** — es el "ojo" que mira lo que se renderizó en el DOM simulado. Tiene tres variantes que vale entender:
```jsx
screen.getByText('algo')    // lo busca y FALLA si no lo encuentra
screen.queryByText('algo')  // lo busca y devuelve null si no está — no falla
screen.findByText('algo')   // lo busca de forma asíncrona — para cuando aparece después
```
**Ahora el test más interesante — simular interacción del usuario:**
```jsx
import { userEvent } from '@testing-library/user-event';

test('llama onChange cuando el usuario escribe', async () => {
  const handleChange = vi.fn(); // función espía — registra si fue llamada
  render(
    <Input
      label="Describe tu meta"
      name="detalles"
      value=""
      onChange={handleChange}
    />
  );
  const input = screen.getByRole('textbox');//busca por rol semántico
  await userEvent.type(input, 'Correr');//simula al usuario escribiendo  
  expect(handleChange).toHaveBeenCalled();// verificás que onChange fue llamado
});
```