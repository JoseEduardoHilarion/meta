`float: left;` Flota a la izquierda de su contenedor y el resto de los elementos lo rodean o envuelven.

Ejemplo: div con 100px de ancho y otro div que tenga el resto  de ancho de la pantalla con un margin de 10px. Se usa `overflow: hidden;` para lograr que el otro div envuelva ya que se sale de flujo.
![[FLOTADOS.png]]
> [!TIP]
> Limpiar tus flotados después de usarlos `clear: both;`.

---
