Es el lienzo o espacio de trabajo que el navegador provee.
tiene un [[width height]] inherentes, es la referencia final para el **html** y el **body**, cuando se aplica width o height al 100%.