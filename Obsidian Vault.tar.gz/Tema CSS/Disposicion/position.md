[[Flujo]] de las [[Box]] pueden ser: block(ocupan todo el width) o inline (no tiene `width ni height` ejemplo los span o los párrafos son inline).
- `position: static;` viene por defecto.
- `position: relative;`Sigue ocupando el espacio en el flujo (por eso es relativo así mismo) habilitando: `top, bottom, left, right, y z-index: 0;`
- `position: absolute;`Sale del flujo y flota, es relativo al primer elemento **ancestro** con posición no estática. Si no existe tal elemento es relativo al `body`.
- `position: fixed;` fijo relativo a la pantalla.
- `position: sticky;` como fixed hasta cierto punto scroll.

![[CSS Posiciones.webm]]

---
