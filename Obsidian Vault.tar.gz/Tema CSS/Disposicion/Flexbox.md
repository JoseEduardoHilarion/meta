
- `flex-direction: column;` `row-reverse;`.
- `justify-content: space-evenly;` (uniforme y simétrica); `space-around; space-between;`.
- `align-items: center;` Opuesto eje.
- `flex-wrap: wrap;` Define el comportamiento de **salto de línea** de los items en un contenedor Flexbox.
-  Dirección al eje o Opuesto se usan: `flex-start; flex-end;`
- **justify** main axis. **align** cross axis.

[Fuente Verdad](https://www.w3.org/TR/css-flexbox-1/)

[Practica Flexbox](https://flexboxfroggy.com/#es)

---
