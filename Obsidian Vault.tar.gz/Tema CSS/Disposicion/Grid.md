#### Padre "Cuadricula 2x3":
- Usando Areas: 
```css
	.layout {
	display: grid;
	height: 100vh;
    /* Aquí redefinimos a dos columnas */
    grid-template-columns: 200px 1fr;
    /* Ajustamos las filas para que el medio sea 1fr */
    grid-template-rows: 50px 1fr 60px;
    gap: 10px;
    grid-template-areas:
      "cabecera cabecera"
      "lateral   principal"
      "pie       pie";
  }
}
/* Usamos el nombre de la etiqueta directamente */
header {grid-area: cabecera;background-color: lightblue;}
aside {grid-area: lateral;background-color: lightcoral;}
main {grid-area: principal;background-color: lightgreen;}
footer {grid-area: pie;background-color: lightgoldenrodyellow;}
```
- `gap: 10px;` Espacio entre celdas filas y columnas o bien: `grid-row-gap y grid-column-gap.`
- `justify-items` (horizontal), `align-items` (vertical) dentro de sus celdas hijas.
- `justify-content` y `align-content` dentro del Contenedor.

#### Hijos:

|  Donde comienza hijo (cabecera)  |   versiones abreviadas  |
| --- | --- |
|`grid-column-start:1;``grid-column-end:-1;`|`grid-column:1/-1;`|
|`grid-row-start:1;``grid-row-end:2;`   |`grid-row:1/2;`|
| | |
|`.header {grid-area: cabecera;}`|`.header {grid-area:1/1/2/4;}` |
|`.sidebar {grid-area: lateral;}` |`.sidebar {grid-area:2/1/3/2;}` |
|`.main {grid-area:PRINCIPAL;}` | `.main {grid-area:2/2/3/4;}`|
|`.footer {grid-area:pie;}` |`.footer {grid-area:3/1/4/4;}` |
[Practica Grid](http://cssgridgarden.com/#es)

---