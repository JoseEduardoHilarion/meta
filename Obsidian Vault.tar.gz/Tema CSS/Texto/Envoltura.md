```CSS
text-wrap: balance; /*Intenta distribuir el texto de manera que el número de caracteres en cada línea sea lo más parecido posible. */
text-wrap: pretty; /*Texto hermoso, NO SOPORTADO por todos los navegadores*/
```