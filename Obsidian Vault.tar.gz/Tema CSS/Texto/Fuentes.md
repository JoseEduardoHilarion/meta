[Fonts Google](https://fonts.google.com/)

Al usar **link** o **@import** necesitas internet para que el navegador use estas fuentes. Cuando bajas las fuentes y las incluyes en tu proyecto, las puedes usar sin internet.

> [!TIP]
> Utiliza una familia de fuentes genéricas.

---
