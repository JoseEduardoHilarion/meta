```CSS
text-shadow: 2px 2px 4px var(--black-transparente); /*Sombra del texto */
text-decoration: underline; /*Subrayado del texto */
```