```CSS
letter-spacing: 0.1rem; /*Espacio entre letras */
word-spacing: 0.2rem; /*Espacio entre palabras */
text-align: center; /*Alineación del texto al centro */
text-align: justify; /*Alineación del texto justificado */
```