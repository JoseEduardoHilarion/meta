
```CSS
text-transform: lowercase;
text-transform: capitalize;/*La primera letra de cada palabra MAYUSCULA */
```