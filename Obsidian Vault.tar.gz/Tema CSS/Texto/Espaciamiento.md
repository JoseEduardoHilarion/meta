```CSS
white-space: nowrap; /*No hay saltos de línea */
word-wrap: break-word;/*divida la palabra y la envíe a la siguiente línea en lugar de dejar que se desborde. */
```