1. ***Que es CSS?***

2. ***Como se aplica CSS a un documento HTML***
	A través de la etiqueta style, o bien enlazando una hoja de estilo externa, o con CSS en linea.
3. ***Que es un selector en CSS?***
	Un patron usado para seleccionar los elementos a los que se aplicara un conjunto de reglas
4. ***Como se cambia el color de fondo de un elemento?***
	Usando la propiedad background-color: blue; por ejemplo a azul.
5. ***Que es una pseudo-clase en CSS?***
	Una palabra clave añadida a los selectores que especifica un estado especial del elemento seleccionado.
6. ***Como se añade un borde a un elemento?***
	con border: 2px solid black;
7. ***Que es el box Model en CSS?***
	Un modelo que describe como se componen los diferentes elementos de la pagina, incluyendo margenes bordes relleno y contenido.
8. ***Como se centra un elemento?***
	margin: auto; text-align: center;
9. ***Que es la herencia en CSS?***
	Es cuando los elementos hijos heredan propiedades de sus elementos padres o contenedores.
10. ***Como se cambia el tamaño de una fuente?***
	Con la propiedad font-size: 16px; por ejemplo.
11. ***Que es media query en CSS?***
	Una técnica aplica en CSS para aplicar estilos diferentes según las caracteristicas del dispositivo como su anchura, altura o orientacion.
12. ***Como se aplica estilos solo a elementos específicos?***
	Usando los selectores como ID, clases por ejemplo.
13. ***Que hace la propiedad display?***
	Especifica el tipo de caja de visualización utilizado por un elemento ejemplo inline, block, flex, grid.
14. ***Como se crea un transición en CSS?***
	Usando la propiedad transition: all 0.5s ease; por ejemplo.
15. ***Que es flex-box en CSS?***
	Un modelo de diseño que permite alinear y distribuir espacios entre elementos de una interfaz y estructuras complejas con un diseño mas flexible.
16. ***Como se aplica un gradiente como fondo?***
	Usando la propiedad background: linear-gradient(red,yellow); por ejemplo.
17. ***Que es la opacidad en CSS?***
	Una propiedad que define la transparencia de un elemento ejemplo opacity: 0.5;
18. ***Como se usa un atributo como selector?***
	![[atributo como selector]]

19. ***Que es el posicionamiento en CSS?***
	Se refiere a propiedades como position, para controlar como se coloca un elemento en la pagina.
20. ***Como se establece la visibilidad de un elemento?***
		con las propiedades visibility: hidden; o bien display: none;
		
