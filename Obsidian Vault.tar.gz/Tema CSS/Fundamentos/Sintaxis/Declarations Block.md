Es el conjunto de una o más declaraciones encerradas entre llaves {}
