![[SINTAXIS.png]]

---
