Combina un [[Group of Selectors]] con un  [[Declarations Block]].
