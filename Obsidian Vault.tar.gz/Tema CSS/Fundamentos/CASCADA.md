El **orden** importa en CSS. Cuando dos reglas tienen la misma especificidad, **la última declarada gana**.

## Los tres factores que determinan qué estilo se aplica (en orden de peso):

1. **Origen e importancia:** `!important` > estilos del autor > estilos del navegador.
2. **[[ESPECIFICIDAD]]:** cuán específico es el selector (id > clase > etiqueta).
3. **Orden de aparición:** si todo lo anterior es igual, gana la regla que aparece más abajo en el CSS.

```css
/* Ambas reglas apuntan al mismo párrafo */
p { color: blue; }
p { color: red; }  /* ← Esta gana por orden de aparición */
```

> [!tip]
> Evitá `!important` siempre que puedas. Rompe la cascada natural y hace el código difícil de mantener. Si lo necesitás, es señal de que la arquitectura de selectores necesita revisión.

Relacionado con [[ESPECIFICIDAD]] y [[HERENCIA]].

---
