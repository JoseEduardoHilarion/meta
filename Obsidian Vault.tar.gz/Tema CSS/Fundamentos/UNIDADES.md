[Mozilla Valor y Unidades](https://developer.mozilla.org/es/docs/Learn/CSS/Building_blocks/Values_and_units)

> [!TIP]
> Considera el uso de unidades relativas como **em**, **rem** y **\%** para crear diseños más flexibles.

---
