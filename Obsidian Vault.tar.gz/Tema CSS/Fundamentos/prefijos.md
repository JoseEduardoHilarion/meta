Es común en un proyecto tan solo soportar los navegadores más populares (Chrome, Firefox, Safari, Edge) y algunas de sus versiones más modernas (las últimas 3 versiones).

[herramienta que permite añadir prefijos](https://www.npmjs.com/package/autoprefixer)

[respaldo de propiedades de CSS](https://caniuse.com/)

Ejemplo:
```CSS
body {  
	background:-webkit-radial-gradient(ellipse at center, #fff, black);  
	background:-moz-radial-gradient(ellipse at center,#fff,black);  
	background:radial-gradient(ellipse at center,#fff,black);  
}
```