Elemento hijo hereda los estilos del padre, pero esto no se aplica a todos los estilos ya que sería un dolor de cabeza. Estilos como el color heredan porque es algo regularmente deseado.

[Mozilla Herencia](https://developer.mozilla.org/es/docs/Web/CSS/inheritance) o bien 
[Mozilla Cascada y Herencia](https://developer.mozilla.org/es/docs/Learn/CSS/Building_blocks/Cascade_and_inheritance)

> [!TIP]
> No uses **etiquetas universales** con demasiada frecuencia, debido a su amplio alcance. En lugar de ello, utiliza selectores de **clase** o **ID** para tener un control más específico.

---
