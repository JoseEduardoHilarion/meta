[CSS Tools](https://meyerweb.com/eric/tools/css/reset/), o bien [Normalize](https://necolas.github.io/normalize.css/)

---

