**Texto**: Dentro de su contenedor `text-align`.
```CSS
.contenedor {
  text-align: center;
}
```
**Bloque:** Como un div, imagen o un párrafo **que ocupa todo el ancho**.
```CSS
.contenedor-bloque {
  width: 50%; /* O cualquier ancho específico */
  margin: 0 auto;
  /*márgenes superior e inferior en `0` y que distribuya automáticamente el espacio restante a los lados, centrando así el elemento.*/
}
```
**Flexbox contenedor padre:**
```CSS
.contenedor-flex {
  display: flex;
  justify-content: center; /* Centra horizontalmente */
  align-items: center; /* Centra verticalmente */
  height: 100vh; /* Establece una altura para el contenedor */
}
```
**Grid contenedor padre:**
```CSS
.contenedor-grid {
  display: grid;
  place-items: center; /* Centra tanto horizontal como verticalmente */
  height: 100vh; /* Establece una altura para el contenedor */
}
```
**Position absolute:**
```CSS
.contenedor-padre {
  position: relative;}
  
.elemento-a-centrar {
  position: absolute;  
  /*ESQUINA superior izquierda en CENTRO del contenedor.*/
  top: 50%;
  left: 50%;  
  /*Hacia atrás en un 50% de su propio ancho y altura, colocándolo CENTRO.*/
  transform: translate(-50%, -50%);}
```

---
