[Valor de la especificidad](https://polypane.app/css-specificity-calculator/#selector)

> [!TIP]
> Error **sobre-especificación** innecesaria. Utiliza selectores de **clase** en lugar de selectores de **id** o de **etiquetas** cuando sea posible. Recuerda, menos es más en muchas situaciones, y este es un buen ejemplo de ello.

---
