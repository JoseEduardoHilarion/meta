[Fuente de la verdad](https://drafts.csswg.org/selectors-3/#selector)

- **p[title]** todas las etiquetas p que tienen el atributo title .
![[atributo como selector]]
- **\*** selecciona todos los elementos.
- **p > div** selecciona la etiqueta div que es hija de un a etiqueta p.
- **button:hover** selecciona el botón cuando el cursor está sobre el botón.
- **div::after** selecciona una etiqueta 'ficticia' que se crea después de elemento div.


---



