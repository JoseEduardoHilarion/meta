Según el dispositivo o el tipo de medio (como pantalla `screen`, impresión`print`.

Mobile First
```CSS
.menu { 
	display: flex;
	flex-direction: column;} 
	
@media screen and (min-width: 768px) {
	/*Pantallas sea de 768px como minimo, entonces es Desktop*/
	.menu { flex-direction: row; } 
	}
```
Herramienta esencial para la **imprimibilidad**
```CSS
@media print {
	nav, aside, .ads, .button { 
		display: none; } 
		
	body { 
		font-family: Georgia, serif;
		font-size: 12pt;
		color: black;
		background-color: white; }
	}
```

[Uso de @media](https://developer.mozilla.org/es/docs/Web/CSS/Media_Queries/Using_media_queries)

---
