A diferencia de [[@media queries]], que aplica estilos basados en las características del [[viewport]], `@container` aplica estilos basados en el tamaño del **contenedor** en el que se encuentra un **componente Hijo**.
1. Definimos el contenedor sidebar "barra lateral":
```CSS
.sidebar { 
	container-type: inline-size; /*OBSERVANDO los cambios de width*/
}
```

2. Los hijos de sidebar "barra lateral":
```CSS
.product-card { 
	display: flex;
	flex-direction: column; } 
	
@container (min-width: 300px) { 
	/*CONTENEDOR(sidebar) de .product-card es 300px o más de ancho*/ 
	.product-card {
		flex-direction: row; /* Cambia a una dirección horizontal */
		align-items: center; }
		}
```

---
