[Mozilla transform](https://developer.mozilla.org/en-US/docs/Web/CSS/transform)

**2D**
- `translate()` Lo mueve a lo largo del eje X, Y.
- `rotate()` Usan unidades como `deg` (grados) o `rad` (radianes)
- `scale()` `transform: scale(1.5);`
- `skew()` `transform: skew(20deg, 10deg);` (Inclina 20 grados en el eje X y 10 en el eje Y)

**3D**
- `translate3d()` Mientras la z lo mueve hacia adelante o atrás en el eje de profundidad.
- `rotateZ()` Rota alrededor de su eje de produndidad.
- `scale3d()`
- `perspective()` Se aplica al Padre, se crea un punto de fuga, creando una ilusión de profundidad.
- `transform-style: preserve-3d;` **Contexto jerárquico** crea un **nuevo contexto 3d para los hijos**, un solo contexto para el padre junto a los hijos.

---
