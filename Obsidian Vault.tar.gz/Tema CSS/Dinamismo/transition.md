- `transition-property`: Indica cuál es la propiedad CSS que quieres animar: `background-color`,`width, height`,`all` para animar cualquier propiedad.    
- `transition-duration`: **Esta es la más importante.** Define el tiempo que durará la transición, se mide en segundos (`s`).    
- `transition-timing-function`: Curva de velocidad de la animación. `ease` (empieza lento, acelera en el medio, y termina lento), `linear`, `ease-in` (empieza lento), `ease-out` (termina lento) o `ease-in-out` (empieza y termina lento).
- `transition-delay`: Pausa antes de que la animación comience.
- Ejemplo:
```CSS
.boton {
	  padding: 10px 20px;
	  font-size: 16px;
	  background-color: green;
	  border-radius: 5px;
	  /* Anima todas las propiedades que cambien en 0.3 segundos */
	  transition: all 0.3s ease; 
}
.boton:hover {
	  background-color: darkgreen;
	  transform: scale(1.1);
	  /* También se animará gracias a `transition: all` */
}
```


[Mozilla transition](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_animated_properties) o bien [easing webflow](https://easing.webflow.io/)

---
