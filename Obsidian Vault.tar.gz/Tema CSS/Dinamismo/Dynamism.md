Capacidad de una web de **cambiar su estilo y apariencia** en tiempo real.
![[transform]]
![[transition]]
![[animation]]