1. `@keyframes`: Puntos específicos de la línea de tiempo (0%, 50% y 100% de la animación). Les das un nombre único, como `deslizamiento` o `rotación`, para poder usarlas.    
2. **Las propiedades de animación**: 
	- `animation-name`    
	- `animation-duration`	    
	- `animation-timing-function`:Similar a la de las transiciones (`ease`, `linear`, etc.).	    
	- `animation-delay`: Tiempo de espera antes que la animación comience.	    
	- `animation-iteration-count`: `infinite` bucle infinito.	    
	- `animation-direction`: La dirección (`normal`, `reverse`, o `alternate` para un efecto de ida y vuelta).	    
	- `animation-fill-mode`: Define el estilo del elemento antes y después de que la animación se complete (`forwards` para mantener el estilo del último fotograma).
	
[Mozilla animation](https://developer.mozilla.org/en-US/docs/Web/CSS/animation)

> [!tip] 
> Usa **porcentajes** en vez de pixeles.

Ejemplo:
```CSS
.boton {
	  padding: 15px;
	  background-color: #f1c40f;
	  animation: pulso 1s ease-in-out infinite alternate;}
@keyframes pulso {
  from {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(241, 196, 15, 0.7);}
  to {
    transform: scale(1.1);
    box-shadow: 0 0 10px 10px rgba(241, 196, 15, 0);}
}
```

---

