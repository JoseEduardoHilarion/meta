**Crean** un **elemento virtual** que no existe en el DOM.
1. `::before` y `::after`: Añadir iconos, citas, decoraciones o textos adicionales.
```CSS
<style>
h2::before {
		content: "•";/* Añade un bullet point antes del encabezado */
		color: #3498db;
		margin-right: 5px;}

.tooltip::after {
		content: attr(data-tooltip);
		color: green;
		visibility: hidden;}
		
.tooltip:hover::after {
		visibility: visible;}
</style>
<h2>Este es el H2</h2>
<span class="tooltip" data-tooltip="Este es un texto de ayuda">
TEXTO PRINCIPAL </span>
```
2. `::first-line`: Primera línea de texto de un elemento de bloque (como un párrafo).
3. `::first-letter`: Primera letra del primer texto.
4. `::selection`: Texto que el usuario ha seleccionado.

---
