- Todos los `input` de tipo `text`, sin necesidad de añadir una clase.
    
    ```CSS
    		input[type="text"] { 
    			border: 1px solid #ccc; }
    ```
    
- Estados actuales: `checked`, `disabled`, o `required`
    
    ```CSS
    		input[disabled] {
    			  opacity: 0.6;}
    ```
    
- Todos los enlaces cuyo atributo `href` comienza con `http`.
    
    ```CSS
    		a[href^="http"] {
    			  color: blue;}
    ```

---