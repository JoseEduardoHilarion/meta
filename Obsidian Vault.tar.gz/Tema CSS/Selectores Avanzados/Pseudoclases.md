Crear interfaces de usuario **dinámicas y accesibles** sin necesidad de usar JavaScript. Según su **interacción**, o su **posición en el DOM** o si contiene **ciertos atributos**.

1. **interacción:** `:hover`, `:active`, `:focus`, `:visited`.
2. **posición:** `:first-child`, `:last-child`, `:nth-child(n)`: El enésimo hijo de su padre. Es muy útil para dar estilos a filas alternas en una tabla.
3. Elementos de **formulario** según su **estado**:
	- `:checked`: Un `radio button`, `checkbox` o `option` que ha sido seleccionado.    
	- `:disabled`: Un campo de formulario que está deshabilitado.    
	- `:invalid`: Un campo de formulario cuyo valor no cumple con sus requisitos (por ejemplo, un email sin `@`).
4. Otras pseudoclases:
	- `:empty`: Selecciona un elemento que no tiene hijos (ni texto).    
	- `:not()`: Aplica estilos a todos los elementos que **no** cumplan con el selector entre paréntesis.    
	- `:root`: Selecciona el elemento raíz del documento (`<html>`).    
	- `:target`: Selecciona un elemento que ha sido el destino de un enlace de anclaje (por ejemplo, `href="#seccion"`).

---
