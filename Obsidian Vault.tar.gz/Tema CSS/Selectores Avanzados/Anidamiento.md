El símbolo **`&`** se convierte en la clave para referenciar el nombre del bloque, o selector Padre.
```CSS
nav { 
	/* Estilos del contenedor */ 
	a{ 
		/* Estilos de los enlaces */ 
		&:hover { 
			/* Estilos al pasar el cursor */ 
		} 
	} 
}
```

**BEM** Metodologia de nomenclatura para clases CSS.
- **Bloque**: Un componente principal e independiente. (Ej: `.card`, `.button`) 
- **Elemento**: Una parte del bloque que no puede existir por sí sola, usa dos guiones bajos. (Ej: `.card__header`, `.button__icon`) 
- **Modificador**: Una bandera que cambia la apariencia o el comportamiento de un bloque o un elemento. Usa dos guiones. (Ej: `.card--dark`, `.button--disabled`)

```CSS
.card {
	  background-color: #f0f0f0;
	  border: 1px solid #ccc;
	  &__header {
	    font-size: 1.5rem;
	    font-weight: bold;
	  }
	  &__button {
	    color: #fff;
	    background-color: #007bff;
	  }
	  &--dark {
	    background-color: #333;
	    color: #fff;
	  }
}
```

---
