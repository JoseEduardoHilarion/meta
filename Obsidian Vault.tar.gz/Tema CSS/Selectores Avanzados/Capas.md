Imagina que usas una biblioteca de estilos (como Bootstrap) y también escribes tus propios estilos.

- Normalmente, los estilos de Bootstrap podrían sobrescribir los tuyos, o viceversa, creando conflictos inesperados.
    
- Con las capas, puedes declarar un orden: `@layer reset, bootstrap, my-styles;`. Ahora, sabes que `my-styles` siempre tendrá la última palabra, sin importar la especificidad de los selectores que uses. Puedes sobrescribir cualquier estilo de la biblioteca de manera fácil y predecible.

```CSS
@layer base, components, utilities;

@layer base {
  button {
    text-transform: uppercase;}
}
@layer components {
  .button {
    font-weight: normal; /* Estilo en conflicto */
    background-color: #3498db;
    color: white;}
}
@layer utilities {
  .font-bold {
    font-weight: bold; /* Anulará el estilo de 'components' */ }
}
```

---
