[w3 border](https://www.w3.org/TR/css-backgrounds-3/#border-shorthands)

Vas a encontrar que algunos desarrolladores los escriben en diferente orden y aún así funcionan.
```CSS
border: 10px solid red;
border: solid 10px red;
```

---
