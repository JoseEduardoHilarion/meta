![[CAJA.png]]

> [!TIP]
> Recuerda emplear la propiedad `box-sizing: border-box`. Esta propiedad incluirá el **[[border]]** y el **[[padding]]** en el tamaño total de la caja.

---
