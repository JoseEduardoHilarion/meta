Afecta el espacio **interior** o bien **relleno** de la [[Box]].

---
