**CONTORNO:** es una línea que se dibuja **alrededor de su caja**, por fuera del [[border]]. No ocupa espacio en el documento.
```CSS
/*Contorno sólido de 2 píxeles de grosor y color azul */
.mi-caja {
	outline: 2px solid blue;
    }
```

---
