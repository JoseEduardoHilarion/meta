Todo elemento HTML es una **caja rectangular** compuesta por cuatro capas, de adentro hacia afuera:

```
┌─────────────────────────────┐  ← margin (espacio exterior)
│  ┌───────────────────────┐  │  ← border (borde visible)
│  │  ┌─────────────────┐  │  │  ← padding (relleno interior)
│  │  │    CONTENIDO    │  │  │
│  │  └─────────────────┘  │  │
│  └───────────────────────┘  │
└─────────────────────────────┘
```

![[Box]]
![[padding]]
![[border]]
![[outline]]
![[margin]]

## `box-sizing`: la propiedad más importante

Por defecto (`content-box`), `width` y `height` solo miden el **contenido**. El padding y el border se suman encima, lo que hace difícil calcular tamaños.

```css
/* Reset recomendado: incluye border y padding en el tamaño total */
*, *::before, *::after {
  box-sizing: border-box;
}
```

Con `border-box`: si un elemento tiene `width: 200px`, el padding y el border se restan del interior — el elemento **siempre mide 200px** en total.

---
