[Mozilla background](https://developer.mozilla.org/en-US/docs/Web/CSS/background)

> [!TIP]
> Siempre verifica que la ruta de tu imagen de fondo sea correcta y relativa a la hoja de estilo [[Tema CSS/CSS]] y no al documento HTML.
> 
> **Gradiente como fondo**: `background: linear-gradient(red,yelllow);`

---
