[Mozilla color value](https://developer.mozilla.org/en-US/docs/Web/CSS/color_value)
> [!TIP]
> Procura usar códigos de colores **hexadecimales** o **RGB** en lugar de nombres, porque ofrecen un rango más amplio de opciones y no dependen de la interpretación del navegador.

---
