Permiten derivar un nuevo color a partir de uno existente, modificando solo alguno de sus canales (tono, saturación, luminosidad). Muy útiles con variables CSS.

```css
:root {
  --principal: hsl(220, 80%, 50%); /* azul */
}

div {
  /* Mismo color pero 20% más oscuro (luminosidad reducida) */
  background: hsl(from var(--principal) h s calc(l - 20%));
}

button:hover {
  /* Tono rotado 30 grados (de azul hacia violeta) */
  background: hsl(from var(--principal) calc(h + 30) s l);
}
```

> [!tip]
> Esta sintaxis (`hsl(from ...)`) es parte de la especificación **CSS Color Level 5** y tiene soporte moderno en Chrome, Safari y Firefox. Verificá compatibilidad en [caniuse.com](https://caniuse.com).

Relacionado con [[Modelo de Colores]] y [[color]].

---
