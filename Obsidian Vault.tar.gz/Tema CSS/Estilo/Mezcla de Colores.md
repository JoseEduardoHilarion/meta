Mezcla dos colores en una proporción definida usando `color-mix()`.

```css
:root {
  --primary: #3498db;   /* azul */
  --secondary: #e74c3c; /* rojo */
}

.elemento {
  /* 50% azul + 50% rojo = morado */
  background-color: color-mix(in srgb, var(--primary) 50%, var(--secondary));
}

.sutil {
  /* 80% primario + 20% blanco = versión más clara */
  background-color: color-mix(in srgb, var(--primary) 80%, white);
}
```

> [!tip]
> El espacio de color `srgb` es el más común. También podés usar `oklch` para mezclas perceptualmente más uniformes (los resultados se ven más naturales).

Relacionado con [[Modelo de Colores]] y [[Colores Relativos]].

---
