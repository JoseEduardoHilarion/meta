```jsx
describe('metaReglas', () => {
  // agrupa tests relacionados
  // es como una carpeta con nombre
  test('rechaza descripción vacía', () => {
    // un caso concreto a verificar
    // "si pasa esto..."
    expect(esValido).toBe(false); // "...espero este resultado"
  });
});
```
**patrón AAA**
```jsx
test('rechaza descripción vacía', () => {
  // ARRANGE — preparás los datos de entrada
  const datos = { detalles: '', eventos: '3', meta: '10', completado: '0' };
  // ACT — ejecutás la función
  const { esValido, errores } = metaReglas(datos);
  // ASSERT — verificás el resultado
  expect(esValido).toBe(false);
  expect(errores.detalles).toBeTruthy();
});
```
**Los matchers que usás:**
```jsx
expect(valor).toBe(false)       // es exactamente false
expect(valor).toBeTruthy()      // es verdadero (cualquier cosa no vacía)
expect(valor).toBeFalsy()       // es falso (vacío, null, undefined, false)
expect(valor).toBeUndefined()   // es undefined
expect(valor).toEqual({...})    // tiene la misma estructura (para objetos)
```