```JavaScript
for (let i = 0; i < 5; i++) { 
	console.log(i); }
```

```JavaScript
let numero = 5; 
while (numero < 100) { 
	numero = numero * 2; 
	console.log(numero); }
```
	
```JavaScript
let contador = 0;
do {
  console.log("El contador es: " + contador++);
} while (contador < 3);
```

```JavaScript
const frutas = ['manzana', 'pera', 'uva']; 
for (const fruta of frutas) { 
	console.log(fruta); }
```

```JavaScript
const persona = { nombre: 'Juan', edad: 30 }; 
for (const clave in persona) { 
	console.log(clave + ': ' + persona[clave]); }
```

---