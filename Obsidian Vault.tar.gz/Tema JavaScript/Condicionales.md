## 1. `if / else if / else`
```javascript
const edad = 20;
if (edad < 13) {
  console.log("Niño");
} else if (edad < 18) {
  console.log("Adolescente");
} else {
  console.log("Adulto");
}
```

## 2. Operador Ternario (`?`)
Ideal para asignaciones simples en una sola línea.
```javascript
const acceso = edad >= 18 ? "Permitido" : "Denegado";
```

## 3. `switch`
Mejor que múltiples `if/else` cuando comparás un valor contra muchas opciones fijas.
```javascript
const dia = "lunes";
switch (dia) {
  case "lunes":
  case "martes":
    console.log("Inicio de semana");
    break;
  case "viernes":
    console.log("¡Por fin viernes!");
    break;
  default:
    console.log("Día normal");
}
```

## 4. Nullish Coalescing (`??`) y Optional Chaining (`?.`)
Modernos y muy útiles para manejar valores nulos.
```javascript
const nombre = usuario.nombre ?? "Invitado"; // Usa "Invitado" solo si es null o undefined
const ciudad = usuario?.direccion?.ciudad;   // No lanza error si alguno no existe
```

---
