| Keyword | Scope | Reasignable | Redeclarable | Hoisting |
|---|---|---|---|---|
| `var` | función o global | ✅ | ✅ | ✅ (inicializada como `undefined`) |
| `let` | bloque `{}` | ✅ | ❌ | ✅ (pero no inicializada → TDZ) |
| `const` | bloque `{}` | ❌ | ❌ | ✅ (pero no inicializada → TDZ) |

> **TDZ (Temporal Dead Zone):** la zona entre el inicio del bloque y la declaración, donde la variable existe pero no se puede leer. Acceder a ella lanza `ReferenceError`.

## Regla práctica:
Usá siempre `const`. Si necesitás reasignar, usá `let`. Evitá `var`.

```javascript
const PI = 3.14;         // No cambia nunca ✅
let contador = 0;        // Va a cambiar ✅
contador++;

// const no impide mutar un objeto o array
const usuario = { nombre: "Ana" };
usuario.nombre = "Luis"; // ✅ Esto funciona
usuario = {};            // ❌ Error: no podés reasignar la variable
```

[Palabras reservadas en JavaScript](https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Lexical_grammar#palabras_clave)

---
