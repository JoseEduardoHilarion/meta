Es un objeto que podemos usar para añadir funcionalidad reutilizable a otro objeto o clase, sin usar herencia. No podemos usar mixins por sí solos: su único propósito es _añadir funcionalidad_ a objetos o clases sin herencia.

```JavaScript
class Perro {
    constructor(name) {
        this.name = name;
    }
}
const funcionalidadPerro = {
    bark() { return console.log("Woof!") },
    wagTail() { return console.log("Wagging my tail!") },
    play() { return console.log("Playing!") },
};
Object.assign(Perro.prototype, funcionalidadPerro);

const pet2 = new Perro("Daisy");
pet2.bark(); 
pet2.wagTail();
pet2.play();
```

¡Perfecto! Los mixins nos permiten añadir fácilmente funcionalidades personalizadas a clases u objetos sin usar herencia.

|Escenario|Resultado|¿Buena o Mala Práctica?|
|---|---|---|
|Mala `Object.assign( Object.prototype, mixin)`|**Contamina** el prototipo **global** de todos los objetos en el programa.|**MALA PRÁCTICA** (Genera contaminación global).|
|Aceptable `Object.assign( MiClase.prototype, mixin)`|Modifica el prototipo de **una clase específica** (`MiClase`).|**Aceptable/Tradicional** para _mixins_. Menos riesgo que la A, pero aún modifica el prototipo.|
|Mejor `const instancia = Object.assign( {}, mixin, data);`|Modifica **solo la instancia** del objeto, no el prototipo compartido.|**BUENA PRÁCTICA** (==Composición de objetos==).|

==**Composicion de Objetos**==, **Función de Orden Superior para Clases (Higher-Order Class)**.

Este patrón se enmarca dentro del principio de **Composición sobre Herencia**. En lugar de usar una larga cadena de herencia (`A extiende B extiende C`), se "compone" una clase inyectándole funcionalidades de otras fuentes (los Mixins).

```JavaScript
class Dog {
    constructor(name) {
        this.name = name;
    }
}
const dogFunctionality = (ClaseBase) => class extends ClaseBase {
    bark() { return console.log("Woof!") }
    wagTail() { return console.log("Wagging my tail!") }
    play() { return console.log("Playing!") }
};
class SuperDog extends dogFunctionality(Dog) {};

const pet1 = new SuperDog("Daisy");
pet1.bark(); 
pet1.wagTail(); 
pet1.play();
```

---