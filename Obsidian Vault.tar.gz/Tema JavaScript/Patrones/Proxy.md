Es un patrón de diseño estructural que te permite proporcionar un sustituto o marcador de posición para otro objeto. Un proxy controla el acceso al objeto original, permitiéndote hacer algo antes o después de que la solicitud llegue al objeto original.
## Problema
¿Por qué querrías controlar el acceso a un objeto? Imagina que tienes un objeto enorme que consume una gran cantidad de recursos del sistema. Lo necesitas de vez en cuando, pero no siempre.
![[sin proxy.png]]
Puedes llevar a cabo una implementación diferida, es decir, crear este objeto sólo cuando sea realmente necesario. Todos los clientes del objeto tendrán que ejecutar algún código de inicialización diferida. Lamentablemente, esto seguramente generará una gran cantidad de código duplicado.

En un mundo ideal, querríamos meter este código directamente dentro de la clase de nuestro objeto, pero eso no siempre es posible. Por ejemplo, la clase puede ser parte de una biblioteca cerrada de un tercero.
## Solución
El patrón Proxy sugiere que crees una nueva clase proxy con la misma interfaz que un objeto de servicio original. Después actualizas tu aplicación para que pase el objeto proxy a todos los clientes del objeto original. Al recibir una solicitud de un cliente, el proxy crea un objeto de servicio real y le delega todo el trabajo.
![[con proxy.png]]
Pero, ¿cuál es la ventaja? Si necesitas ejecutar algo antes o después de la lógica primaria de la clase, el proxy te permite hacerlo sin cambiar esa clase. Ya que el proxy implementa la misma interfaz que la clase original, puede pasarse a cualquier cliente que espere un objeto de servicio real.

```JavaScript
const handler = {
    set(target, prop, value, receiver) {
        if (prop === "age") {
            if (value > 0)
                Reflect.set(target, prop, value, receiver);
            else
                throw new Error("Edad inválida");
        } else
            Reflect.set(target, prop, value, receiver);
        return true;
    },
    get(objeto, propiedad, receiver){
        return Reflect.get(objeto, propiedad, receiver);
    },
}

function createValidatedUserProxy(user) {
    return new Proxy(user, handler);
}

// Proxy
const user = { name: "Ana", age: 20 };
const uproxy = createValidatedUserProxy(user);
uproxy.age = 30;
console.log(uproxy);

uproxy.name = "hola soy Jose Hilarion";
uproxy.age = 1;
console.log(uproxy.age, uproxy.name);
```

---