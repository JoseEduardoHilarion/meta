Una clase que tiene **una sola instancia**, y proporciona un punto de acceso global a ella. Útil para cosas como configuración global, conexión a base de datos, o un carrito de compras.

## Solución con `class`:
```javascript
class ConfiguracionApp {
  static #instancia = null; // Campo estático privado

  constructor() {
    if (ConfiguracionApp.#instancia) {
      return ConfiguracionApp.#instancia; // Devuelve la misma instancia
    }
    this.tema = "claro";
    this.idioma = "es";
    ConfiguracionApp.#instancia = this;
  }

  static obtener() {
    if (!ConfiguracionApp.#instancia) {
      new ConfiguracionApp();
    }
    return ConfiguracionApp.#instancia;
  }
}

const config1 = ConfiguracionApp.obtener();
const config2 = ConfiguracionApp.obtener();
console.log(config1 === config2); // true → son el mismo objeto
config1.tema = "oscuro";
console.log(config2.tema); // "oscuro" → es la misma instancia
```

## Combinación con Patrón Módulo:
La forma más limpia en JS moderno es exportar una instancia congelada desde un módulo. Ver [[modulo]].

> [!tip]
> El Singleton es útil, pero úsalo con cuidado: hace el código más difícil de testear porque introduce estado global.

---
