# ¿Qué es un patrón de diseño?

Son soluciones habituales a problemas que ocurren con frecuencia en el diseño de software. Son como planos prefabricados que se pueden personalizar para resolver un problema de diseño recurrente en tu código.

No se puede elegir un patrón y copiarlo en el programa como si se tratara de funciones o bibliotecas ya preparadas. El patrón no es una porción específica de código, sino un **concepto general** para resolver un problema particular. Puedes seguir los detalles del patrón e implementar una solución que encaje con las realidades de tu propio programa.

A menudo los patrones se confunden con algoritmos porque ambos conceptos describen soluciones típicas a problemas conocidos. Mientras que un algoritmo siempre define un grupo claro de acciones para lograr un objetivo, un patrón es una **descripción de más alto nivel de una solución**. El código del mismo patrón aplicado a dos programas distintos puede ser diferente.

Una analogía de un algoritmo sería una receta de cocina: ambos cuentan con pasos claros para alcanzar una meta. Por su parte, un patrón es más similar a un plano, ya que puedes observar cómo son su resultado y sus funciones, pero el orden exacto de la implementación depende de ti.
![[singleton]]
![[Proxy]]
![[Prototype]]
![[modulo]]
![[Mixin]]
![[mediador middleware]]

Si deseas aprender más patrones en JavaScript no hay mejor libro que [Learning JavaScript Design Patterns, 2nd Edition [Book] (oreilly.com)](https://www.oreilly.com/library/view/learning-javascript-design/9781098139865/)

Adicionalmente puedes revisar estos recursos en inglés:

[dofactory design-patterns](https://www.dofactory.com/javascript/design-patterns)

[toptal design-patterns](https://www.toptal.com/javascript/comprehensive-guide-javascript-design-patterns)

[digitalocean design-patterns](https://www.digitalocean.com/community/tutorial_series/javascript-design-patterns)