Además de poder dividir el código en fragmentos reutilizables más pequeños, los módulos permiten mantener ciertos valores dentro del archivo _como privados_ . Las declaraciones dentro de un módulo se encapsulan _en_ ese módulo por defecto. Si no se exporta explícitamente un valor, este no estará disponible fuera del módulo. Esto reduce el riesgo de conflictos de nombres para valores declarados en otras partes del código base, ya que no están disponibles en el ámbito global.

```JavaScript
/* Combinacion de Patron Modulo y Singleton.  
Patron Modulo: Encapsula el codigo y expone solo lo necesario.  
Patron Singleton: Una UNICA instancia y proporciona un punto de acceso global a esa instancia.*/
  
class ModuloUsuarios {  
    constructor() {  
        this.usuarios = [];  
    }  
    agregar(usuario) {  
        this.usuarios.push(usuario);  
        console.log(`Usuario '${usuario.nombre}' agregado.`);  
    }  
    mostrar() {  
        console.log("Lista de usuarios:");  
        this.usuarios.forEach(usuario => console.log(usuario.nombre));  
    }  
}  
export const moduloUsuarios = Object.freeze(new ModuloUsuarios());

////////////////////////////////////////////////////////
/////////en el otro  archivo retroPatrones.js///////////  
import {moduloUsuarios} from "./MUsuarios.mjs"
  
moduloUsuarios.agregar({nombre:'Juan'});  
moduloUsuarios.agregar({nombre:'María'});  
moduloUsuarios.mostrar();
```

## Importación dinámica

Al importar todos los módulos de la parte superior de un archivo, todos se cargan antes que el resto. En algunos casos, solo necesitamos importar un módulo según una condición específica. Con una **importación dinámica** , podemos importar módulos a demanda.

```JavaScript
import("module").then((module) => {
  module.default();
  module.namedExport();
});

// Or with async/await
(async () => {
  const module = await import("module");
  module.default();
  module.namedExport();
})();
```

[Patterns Modulo](https://www-patterns-dev.translate.goog/vanilla/module-pattern/?_x_tr_sl=en&_x_tr_tl=es&_x_tr_hl=es&_x_tr_pto=tc)
## - **Compatibilidad:**

La sintaxis `import/export` es parte de los **módulos de JavaScript (ESM)**. Para que funcionen en el navegador, necesitas agregar `type="module"` en la etiqueta `<script>`.

```javascript
<script type="module" src="app.js"></script>
```

**Node.js:** Node.js ha soportado tradicionalmente el sistema `require`/`module.exports`. Sin embargo, con versiones más recientes, también soporta la sintaxis `import/export` de forma nativa. Para usarla, debes configurar tu archivo `package.json` o usar la extensión `.mjs` para tus archivos.

---