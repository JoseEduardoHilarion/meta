En lugar de comunicarse directamente, el mediador recibe las solicitudes y las reenvía. En JavaScript, el mediador suele ser simplemente un literal de objeto o una función.
![[sin middleware.png]]
En lugar de permitir que cada objeto se comunique directamente con los demás, lo que resulta en una relación de muchos a muchos, las solicitudes de los objetos son gestionadas por el mediador. Este procesa la solicitud y la envía a donde debe estar.
![[con middleware.png]]
Un buen caso de uso para el patrón mediador es una sala de chat. Los usuarios de la sala no se comunican directamente entre sí. En cambio, la sala de chat actúa como mediador entre ellos.
```JavaScript
class ChatRoom {
  logMessage(user, message) {
    const sender = user.getName();
    console.log(`${new Date().toLocaleString()} [${sender}]: ${message}`);
  }
}
class User {
  constructor(name, chatroom) {
    this.name = name;
    this.chatroom = chatroom;
  }
  getName() {
    return this.name;
  }
  send(message) {
    this.chatroom.logMessage(this, message);
  }
}
const chatroom = new ChatRoom();

const user1 = new User("Jose Hilarion", chatroom);
const user2 = new User("Paola Hilarion", chatroom);

user1.send("hola como estan");
user2.send("hay alguien en este grupo!");
```

---