Es un patrón de diseño creacional que nos permite copiar objetos existentes sin que el código dependa de sus clases.
![[imagen prototype.png]]
Funciona así: se crea un grupo de objetos **configurados de maneras diferentes**. Cuando necesites un objeto como el que has **configurado**, clonas un prototipo en lugar de construir un nuevo objeto desde cero.

Prototipo no se basa en la herencia, por lo que no presenta sus inconvenientes. No obstante, _Prototype_ requiere de una **inicialización complicada** del objeto clonado.


```JavaScript
/////Prototipo con funcion Fabrica
const personProto = {
    greet() { return Hola, soy ${this.name}; },
    // Método para crear una copia superficial de sí mismo
    clonar() {
        // 'this' apunta a la instancia que llama a .clone()
        return Object.create(
            Object.getPrototypeOf(this), // Asegura que el clon herede de 'personProto'
            Object.getOwnPropertyDescriptors(this) // Copia propiedades como 'name' y 'age'
        );
    }
};

function createPerson(name) {
    const p = Object.create(personProto);
    p.name = name;
    return p;
}
///Prototipo con Clase
class Prototipo {
    // Método para crear una copia superficial de sí mismo
    clonar() {
        return Object.create(
            Object.getPrototypeOf(this), // Clonar manteniendo el prototipo original
            Object.getOwnPropertyDescriptors(this) // Copiar todas las propiedades propias
        );
    }
}
class Person extends Prototipo {
    constructor(name) {
        super();
        this.name = name;
    }
    greet() { return `Hola, soy ${this.name}`; }
}
///////////////////////////////
let p = new Person("Ana");
let ana = p.clonar();
console.log(ana.greet());

p = createPerson("Ana");
ana = p.clonar();
console.log(ana.greet());
```


---