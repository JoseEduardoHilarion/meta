```JavaScript
function crearContador() {
  let cuenta = 0; // Esta es la variable "privada" (cerrada).

  // La función interna (la closure)
  return function incrementar() {
    cuenta = cuenta + 1;
    return cuenta;
  };
}

// 1. Llamamos a la función externa, que devuelve la función interna (la closure)
const contador1 = crearContador(); 
// En este punto, 'cuenta' (con valor 0) DEBERÍA desaparecer, pero la closure la retiene.

// 2. Ejecutamos la closure fuera de su ámbito original
console.log(contador1()); // Salida: 1 
console.log(contador1()); // Salida: 2 
console.log(contador1()); // Salida: 3 

// 3. Creamos otro contador independiente
const contador2 = crearContador();
console.log(contador2()); // Salida: 1 
```

---