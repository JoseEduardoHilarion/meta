Propiedades `Coche.call(this, marca, modelo)` [[Vinculacion explicita]].


Metodos `CocheElectrico.prototype = Object.create(Coche.prototype)` [[funcion constructora (prototype)]].

```JavaScript
function Animal(nombre, i) {
    let id = i; //propiedad privada (cerrada)
    this.nombre = nombre;
    this.identificacion = function() {
        return id;
    }
}
Animal.prototype.hablar = function() {
    console.log(`${this.nombre} hace un sonido.`);
};
/////////////////////////////////
function Perro(nombre, raza) {
    Animal.call(this, nombre,32); // Llama constructor Animal
    this.raza = raza;
}
// Establece el prototipo de Perro como una nueva instancia de Animal
Perro.prototype = Object.create(Animal.prototype);
// Corrige el constructor para que apunte a Perro
Perro.prototype.constructor = Perro;

Perro.prototype.hablar = function() {
    console.log(`${this.nombre} ladra.`);
};

const miPerro = new Perro('Fido', 'Labrador');
miPerro.hablar(); // Salida: "Fido ladra."
console.log(miPerro.identificacion());
```

> [!tip] 
> Si la función retorna un **valor primitivo** es **ignorado**. Pero si retorna un **objeto**, el valor de retorno explícito **ANULA** el objeto implícito que `new` había creado. 

[ Herencia Prototípica y la cadena de prototipos aquí:](https://developer.mozilla.org/es/docs/Web/JavaScript/Inheritance_and_the_prototype_chain)

---