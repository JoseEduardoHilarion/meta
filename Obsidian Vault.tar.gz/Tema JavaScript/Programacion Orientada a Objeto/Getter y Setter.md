Métodos especiales que controlan cómo se **lee** (`get`) y cómo se **escribe** (`set`) una propiedad. Permiten agregar lógica (validación, transformación) sin cambiar la interfaz del objeto.

## Con `class` (usando `#` para privacidad):
```javascript
class Temperatura {
  #celsius;
  constructor(celsius) {
    this.#celsius = celsius;
  }
  get fahrenheit() {
    return this.#celsius * 9/5 + 32; // Calcula al vuelo
  }
  set celsius(valor) {
    if (valor < -273.15) throw new Error("Por debajo del cero absoluto");
    this.#celsius = valor;
  }
  get celsius() {
    return this.#celsius;
  }
}
const t = new Temperatura(100);
console.log(t.fahrenheit); // 212 (sin paréntesis, parece propiedad)
t.celsius = -300; // ❌ Error: Por debajo del cero absoluto
```

## ¿Por qué usarlos?
- **Validación:** rechazar valores inválidos antes de asignarlos.
- **Propiedades calculadas:** derivar un valor a partir de otros sin guardarlo.
- **Encapsulamiento:** mantener los datos internos privados (`#`) pero accesibles de forma controlada.

Relacionado con [[Encapsulamiento]] y [[class]].

---
