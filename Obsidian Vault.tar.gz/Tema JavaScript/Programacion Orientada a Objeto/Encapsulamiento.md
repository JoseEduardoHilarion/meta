El **encapsulamiento** es el principio de agrupar datos (propiedades) y los métodos que operan sobre esos datos en una sola unidad. También se relaciona con la protección de los datos internos del objeto.

- **Con `class`:** se definen con `#`. Esto asegura que el valor solo pueda ser modificado por métodos dentro de la misma clase.
     ![[class]]
- **Con funciones constructoras/de fábrica:** Se utilizan variables locales dentro de una función de fábrica o constructora. Al no ser propiedades del objeto `this`, son "privadas" y no se puede acceder a ellas desde fuera. Los métodos internos de la función tienen acceso a estas variables a través del concepto de **clausuras** (closures), que las mantienen vivas.
	![[closures]]
	![[funcion constructora(herencia prototype)]]
	![[Getter y Setter]]

---