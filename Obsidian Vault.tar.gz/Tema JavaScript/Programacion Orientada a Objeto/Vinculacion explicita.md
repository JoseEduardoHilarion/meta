 **`this`** apunta al objeto vinculado.(call, apply, bind)
```JavaScript
	function myFunction(param1, param2) {
	    console.log(this)     
	  } 
	const obj = {
	  someKey: 1, 
	}
	const param1 = 1, param2 = 2;
	// this apunta a obj, tanto para call, apply, bind.
	myFunction.call(obj, param1, param2)    
	myFunction.apply(obj, [param1, param2]) 
	const boundFunction = myFunction.bind(obj);
	boundFunction();
```
**No** podemos usar los métodos **call, apply y bind** en las funciones de flecha, porque las funciones de flecha no tienen su propio contexto **`this`**.

[Este blog](https://medium.com/swlh/javascript-this-ac28f8e0f65d#:~:text=Implicit%20binding%20%7C%20Method%20invocation,left%20side%20of%20the%20dot.) y [este otro en español](https://medium.com/sngular-devs/comprende-js-call-apply-y-bind-2e27db35b8c2) incluyen más ejemplos avanzados.

---