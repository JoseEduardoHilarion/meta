La **abstracción** es el acto de mostrar solo las características esenciales de un objeto y ocultar los detalles complejos. Piensa en el control remoto de una televisión: no necesitas saber cómo funcionan los circuitos internos para cambiar de canal. En JavaScript, esto se logra a través de la interfaz pública de un objeto (sus métodos y propiedades accesibles).
![[instanciar]]

---