## 1. Básica

```JavaScript
function crearPajaro(especie) {
  // Crea y devuelve un objeto literal NUEVO en cada llamada
  return {
    especie: especie,
    volar: function() {
      console.log(`${this.especie} está volando de forma básica.`);
    }
  };
}

const pajaroA = crearPajaro('Colibrí');
pajaroA.volar(); // Salida: Colibrí está volando de forma básica.
```
## 2. Optimización con `Object.create()`

Este es el patrón más eficiente. Delega los métodos a un objeto prototipo (`pajaroMetodos`) para ahorrar memoria.

```JavaScript
// Objeto que contiene los métodos (el prototipo)
const pajaroMetodos = {
    volar() {
        // 'this' apuntará al objeto de la instancia (pajaroB o pajaroC)
        console.log(`${this.especie} está volando eficientemente.`);
    }
};

function crearPajaroOptimo(especie) {
    // Usa Object.create para vincular el prototipo
    const nuevoPajaro = Object.create(pajaroMetodos);
    
    // Asigna solo las propiedades de datos
    nuevoPajaro.especie = especie; 
    
    return nuevoPajaro;
}

const pajaroB = crearPajaroOptimo('Águila');
pajaroB.volar(); // Salida: Águila está volando eficientemente.
```


|Patrón|Mecanismo|¿Cómo se logran los métodos compartidos?|¿Cuándo usarlo?|
|---|---|---|---|
|**Básica**|`return { ... }`|Se duplican en cada objeto.|Para objetos muy simples y únicos, o si solo necesitas un par de instancias.|
|**Optimizacion con `Object.create`**|`Object.create(prototipo)`|**Delegación:** Se heredan de un objeto prototipo.|Cuando quieres **eficiencia**, **flexibilidad** (composición) y **encapsulación** (clausuras).|
