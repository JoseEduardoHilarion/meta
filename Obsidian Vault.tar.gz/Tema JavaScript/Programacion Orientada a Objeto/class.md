- **class extends:** `class CocheElectrico extends Coche`. 
```JavaScript
class Animal {
  #id;
  constructor(nombre) {
    this.nombre = nombre;
  }
  hablar() {
    console.log(`${this.nombre} hace un sonido.`);
  }
  set identificacion(i){
    this.#id=i;
  }
}
////////////////////////////////////////////
class Perro extends Animal {
  constructor(nombre, raza) {
    super(nombre); // Llama al constructor de la clase padre (Animal)
    this.raza = raza;
  }
  hablar() {
    console.log(`${this.nombre} ladra.`);
  }
}
///////////////////////////////////////////
const miPerro = new Perro('Fido', 'Labrador');
miPerro.hablar(); // Salida: "Fido ladra."


```
