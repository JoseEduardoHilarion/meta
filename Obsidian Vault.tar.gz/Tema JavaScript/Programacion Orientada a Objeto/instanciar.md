- ![[funcion Fabrica]]
- ![[funcion constructora (prototype)]]
- ![[funcion constructora(herencia prototype)]]
- ![[class]]

---