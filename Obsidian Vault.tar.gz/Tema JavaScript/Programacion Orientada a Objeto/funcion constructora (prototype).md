 Eficiente: El método `acelerar` existe **una sola vez en memoria** en el prototype `Coche`, entonces todas las instancias como `miCoche` y `otroCoche` lo heredan.
```JavaScript
function Coche(marca, modelo) {
  this.marca = marca;
  this.modelo = modelo;
}
// Añadimos el método 'acelerar' al prototipo
Coche.prototype.acelerar = function() {
  console.log(`El ${this.marca} ${this.modelo} está acelerando.`);
};
const miCoche = new Coche('Ford', 'Fiesta');
const otroCoche = new Coche('Toyota', 'Corolla');
miCoche.acelerar();   // Salida: El Ford Fiesta está acelerando.
otroCoche.acelerar();  // Salida: El Toyota Corolla está acelerando.
```


> [!TIP] 
>Confusión entre el prototipo de una función constructora y el objeto que se crea a partir de ella. Recuerda que el objeto tiene su propio conjunto de propiedades, pero también tiene acceso a las propiedades y métodos de su prototipo. Por lo tanto, no añadas propiedades al objeto cuando deberías añadirlas al prototipo.
