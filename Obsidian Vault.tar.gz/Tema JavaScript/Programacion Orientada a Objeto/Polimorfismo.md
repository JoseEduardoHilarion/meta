El **polimorfismo** significa "muchas formas". Es la capacidad de los objetos de diferentes clases para responder a la misma llamada de método de maneras distintas.

- **Con `class`:** Esto se logra sobrescribiendo (o "overrideando") un método del padre en la clase hija.
![[class]]    
- **Con funciones constructoras/prototipos:** El mismo efecto se logra al definir un método con el mismo nombre en el prototipo de la función constructora hija. El intérprete de JavaScript siempre buscará primero el método en el objeto y luego subirá por la cadena de prototipos, lo que permite que el método de la "clase" hija prevalezca.
![[funcion constructora(herencia prototype)]]


---