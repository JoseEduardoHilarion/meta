[Mozilla Regex](https://developer.mozilla.org/es/docs/Web/JavaScript/Guide/Regular_Expressions/Cheatsheet)
- **Clases de caracteres:** Representan un conjunto de caracteres. Por ejemplo, `\d` significa "cualquier dígito" y `\w` significa "cualquier carácter alfanumérico".    
- **Cuantificadores:** Indican cuántas veces debe repetirse un carácter o grupo. Por ejemplo, `+` significa "una o más veces" y `{3,5}` significa "entre 3 y 5 veces".    
- **Anclajes:** Marcan la posición del patrón. `^` significa el inicio de la línea y `$` el final.

Imagina que tienes una lista de números de teléfono y quieres encontrar solo aquellos que siguen el formato de 10 dígitos (por ejemplo, `123-456-7890`).

La expresión regular sería: `let regex=\d{3}-\d{3}-\d{4};`.
- `\d` significa "cualquier dígito" (del 0 al 9).    
- `{3}` significa "repite el patrón anterior 3 veces".    
- `-` significa "busca el carácter guion".
- Usa Herramientas Interactiva:[Regexr](https://regexr.com/) o bien
[Regex101](https://regex101.com/)

---
