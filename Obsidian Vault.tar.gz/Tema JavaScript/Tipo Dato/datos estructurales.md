![[objeto]]
![[lista]]
![[Expresion regular]]
### `Map, Set, WeakMap, WeakSet, Date`

---
### `let mifuncion = function(){};`

---
