- **Validación de formularios:** `trim()`, `toLowerCase()`, `includes()`, `length`,  `endsWith` para verificar y limpiar entradas de usuario.
    
- **Manipulación de datos:** `split()`, `slice()`, `replace()`, `indexOf()` para procesar datos de una base de datos o una API.
    
- **Formatos de texto:** `toUpperCase()`, `toLowerCase()`, `search()`, `match()`.
	
| Característica  | search()  | match()  |
|---|---|---|
|Valor de Retorno|Índice de la primera coincidencia o -1.|Array de coincidencias o null.|
|Banderas de Regex|Ignora las banderas global (g) y sticky (y).|Respeta completamente la bandera global (g) y otras.|
|Caso de Uso|Verificar si un patrón existe y su primera posición.|Extraer todas las ocurrencias de un patrón o información detallada sobre la primera coincidencia.|

---