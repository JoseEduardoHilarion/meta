[Mozilla Plantillas Literales](https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Template_literals)

```JavaScript
	let nombre = "Juan";
	let saludo = `Hola, ${nombre}.`;
	console.log(saludo); // "Hola, Juan."
```