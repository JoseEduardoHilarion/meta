![[primitivos]]
![[datos estructurales]]
### `typeof()` "valida" los parametros.

---
![[Conversion Tipo]]

