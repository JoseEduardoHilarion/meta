- Notación 	
```JavaScript
	const usuario={nombre:"Alice", edad:25, ciudad:"Madrid"}
	console.log(usuario.nombre); // Salida: "Alice"
	console.log(usuario['ciudad']); // Salida: "Madrid"
	// Es útil para claves que tienen espacios o caracteres especiales
	let claveDinamica = 'edad';
	console.log(usuario[claveDinamica]); // Salida: 25
```
- Añadir o modificar:
```JavaScript
	usuario.email = "alice@example.com"; // AÑADE una nueva propiedad
	usuario.edad = 26; // MODIFICA el valor de una propiedad existente
```
- Eliminar:
```JavaScript
	delete usuario.ciudad;
	console.log(usuario); // El objeto ya no tiene la propiedad 'ciudad'
```
- objeto esta vacio?
```JavaScript
	if (Object.keys(usuario).length) {
	  console.log("El objeto no está vacío."); // Se ejecuta esto
	} else {
	  console.log("El objeto está vacío.");
	}
```
- Copia

|  Método | Tipo de Copia  | ¿Cuándo usarlo?  |
|---|---|---|
|{ ...**objeto** }|Superficial|Objetos simples sin objetos anidados.|
|Object.assign(**objeto**)|Superficial|Similar al operador de propagación, para navegadores más antiguos.|
|JSON.parse(JSON.stringify(**objeto**))|Profunda|Objetos con anidamiento, pero sin funciones, Date, etc.|
|Librerías (Lodash) _.cloneDeep(**objeto**)|Profunda|Cuando se necesita una solución robusta y segura para cualquier tipo de objeto.|



> [!tip] 
> Cuando asignas un objeto a una nueva variable o pasas un objeto como argumento, estás asignando una referencia a ese objeto, no una copia. Si modificas el objeto también cambiarás el objeto original. Recuerda hacer una copia.


---