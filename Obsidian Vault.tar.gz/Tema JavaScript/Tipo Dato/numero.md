NO distingue entre `int`, `float` o `double`; son almacenan como números de punto flotante de 64 bits de doble precisión (`float64`). También pueden contener los valores **infinity** y **NaN**(No es un Numero). Y hasta **`2^53 - 1`** (`9,007,199,254,740,991`).

---
