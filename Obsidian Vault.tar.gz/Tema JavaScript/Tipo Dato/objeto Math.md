NO puedes hacer `new Math()`, ya que todos sus métodos y propiedades son estáticos.
- **Propiedades:**
	- `Math.PI;` // 3.141592653589793
	- `Math.E;` // 2.718281828459045
- **Métodos:**
	- **`Math.round()`**: Redondea un número al entero más cercano.    
	- **`Math.floor()`**: Redondea un número hacia abajo al entero más cercano.
	- **`Math.ceil()`**: Redondea un número hacia arriba al entero más cercano.
	- **`Math.random()`**: Genera un número pseudo-aleatorio entre 0 (inclusive) y 1 (exclusivo).
	- **`Math.max()` y `Math.min()`**: Devuelven el valor más grande o más pequeño de los argumentos que les pases.
	- **`Math.pow()`**: Eleva un número a una potencia.
	- **`Math.sqrt()`**: Raíz cuadrada de un número.
	- **`Math.abs()`**: Absoluto de un número.

---

