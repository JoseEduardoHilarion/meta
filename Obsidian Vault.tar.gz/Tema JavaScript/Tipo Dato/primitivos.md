![[texto]]
![[numero]]
![[objeto Math]]
![[BigInt]]
### Booleanos `true` o `false`.

---
### Indefinidos `undefined`.

---
### `symbol()`.

---
### `null` primitivo y estructural.
`let jose= null;`

---
- ![[plantillas literales]]
