- Añadiendo `n` al final de un número entero:
	```JavaScript
	const numeroGrande = 12345678901234567890n;
	console.log(typeof numeroGrande); // "bigint"
	```
- Usando la función `BigInt()`:
	```JavaScript
	const numeroDesdeString = BigInt("12345678901234567890");
	console.log(numeroDesdeString); // 12345678901234567890n
	```

### Diferencias Clave con [[numero]]

- **Sin límite de precisión:** A diferencia de [[numero]], `BigInt` puede realizar cálculos con enteros de tamaño arbitrario sin perder precisión.
    
- **No se pueden mezclar:** Debes convertir `BigInt` y [[numero]]ambos al mismo tipo.    
- **No decimales:** `BigInt` NO puedes usarlo para valores con decimales.    
- **Sin métodos `Math`:** No puedes usar  `Math.floor()` o `Math.random()` con valores `BigInt`.    
- **División:** La división con `BigInt` devuelve un valor entero (trunca la parte decimal), mientras que la división con [[numero]] puede devolver un valor flotante.

[mozilla BigInt](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/BigInt)

---
