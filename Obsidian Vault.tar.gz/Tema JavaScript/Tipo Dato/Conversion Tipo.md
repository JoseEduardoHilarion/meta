- numero=242432;

```JavaScript
	numero.tostring();
```

- cadena = "234";

```JavaScript
	+cadena;
	Number(cadena);

```
- boleano

```JavaScript
	!!cadena
	!!numero;
```

---