**arrays**. Es un objeto que te permite almacenar una colección ordenada de elementos, ya sean [[numero]], [[texto]], objetos u otros arrays.

- `length` if(array.length){} //Si no esta vacia, entonces...
- `push()` y `pop()` agrega o elimina al **final**.
- `unshift()` y `shift()` idem pero al **principio**.
- `indexOf()`: Devuelve el primer índice en el que se encuentra un elemento. Si no lo encuentra, devuelve `-1`.    
- `includes()`: Verifica si un elemento existe en el array y devuelve `true` o `false`.
- `splice()` y `slice()`
```JavaScript
	let nums = [1, 2, 3, 4, 5];
	let copia = nums.slice(1, 4);//desde el índice 1 hasta el 3
	console.log(copia); // [2, 3, 4]
	console.log(nums);  // [1, 2, 3, 4, 5] (no se modifica)
	
	let meses = ["ene", "mar", "abr"];
	meses.splice(1, 0, "feb");//índice 1, elimina 0 elementos y añade "feb"
	console.log(meses); // ["ene", "feb", "mar", "abr"]
```

- Recorrer un array

```JavaScript
	let nombres = ["Ana", "Pedro", "Luisa"];
	for (const nombre of nombres) {
	  console.log(nombre);
	}
	// Salida: "Ana", "Pedro", "Luisa"
```
	
```JavaScript
	let precios = [10, 20, 30];
	precios.forEach(precio => {
	  console.log(`El precio es: $${precio}`);
	});
```

---