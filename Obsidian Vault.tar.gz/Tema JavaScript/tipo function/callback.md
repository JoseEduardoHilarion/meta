[devolución de llamada](https://es.wikipedia.org/wiki/Retrollamada_(inform%C3%A1tica))

[El infierno de las devoluciones de llamada](https://callbackhell.com/)

**Estilo de bloqueo**: no existe una relación explícita entre `a` y `b`

```JavaScript
a()
b()
```

**Estilo sin bloqueo**:El trabajo de `a` es hacer lo que tiene que hacer y luego llamar `b`cuando esté terminado. El uso de funciones de esta manera se denomina **devoluciones de llamada (callback)** porque su función de devolución de llamada, en este caso `b`, se le llama más tarde cuando `a`Todo está hecho.

```JavaScript
a(b)
```
Espero que ahora puedas ver que las devoluciones de llamada son simplemente funciones que invocan otras funciones después de una tarea asincrónica. 

Ejemplos comunes de tareas asincrónicas son: leer una foto, descargar una canción, subir una imagen, comunicarse con una base de datos, esperar a que un usuario presione una tecla o haga clic en alguien, etc. **Cualquier tarea que requiera tiempo**. JavaScript es realmente excelente para gestionar tareas asincrónicas como estas, siempre y cuando te tomes el tiempo de aprender a usar las devoluciones de llamada y evitar que tu JavaScript se bloquee.


---




