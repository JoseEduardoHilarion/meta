1. **function**

```JavaScript
	function saludar(nombre) { // nombre es PARAMETRO
	  return "Hola, " + nombre;
	}// Si no hay return devuelve `undefined`.
	saludar("hola"); // "hola" es ARGUMENTO
```

2. **Expression**
```JavaScript
	const saludar = function(nombre) {
	  return "Hola, " + nombre;
	};
```
3. **flecha** => o "Funcion Anonima" [Mozilla Flecha](https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Functions/Arrow_functions)


```JavaScript
	// () => (...)
	const saludar = (nombre) => {
	  return "Hola, " + nombre;
	};	
	// Sintaxis más corta para una sola línea

	const saludar = (nombre) => "Hola, " + nombre;
```


```jsx
//  { } + return
const Contador = () => {
  const [count, setCount] = useState(0);   // ← lógica
  const doble = count * 2;                 // ← lógica

  return (                                  // ← return obligatorio
    <button onClick={() => setCount(count + 1)}>
      {doble}
    </button>
  );
};

```

> [!tip]
> Las funciones de flecha no tienen su propio contexto **`this`**

---