![[declaracion funciones]]
![[ambito]]
![[callback]]
![[this]]

---