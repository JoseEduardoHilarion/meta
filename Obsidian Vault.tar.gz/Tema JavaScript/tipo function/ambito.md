Evita usar **`'var'`**, ya que su **alcance es global o de función** entera, lo cual puede llevar a problemas de sobrescritura o acceso no intencionado. 

En cambio, utiliza **`'let'`** que tiene un **alcance de bloque**.


---