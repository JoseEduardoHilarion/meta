**`this`** apunta a la **llamada a la función (objeto)**, y **no a la función en sí**. Una misma función puede tener diferentes propietarios en diferentes situaciones.

## 1. ==DIRECTA o Predeterminado:==
```javascript
function myFunction() {
    console.log(this) // this apunta al objeto GLOBAL (window en browser, global en Node)
}
myFunction(); // enlace DIRECTO
```

## 2. ==IMPLÍCITA o Invocación de método:==
```javascript
function myFunction() {
    console.log(this) // apuntará al objeto mediante el cual se invocó: "obj"
}
const obj = {
  someKey: 1,
  myFunction: myFunction,
}
obj.myFunction(); // enlace IMPLÍCITO (el punto)
```

## 2A. ==Función anidada:==
```javascript
const obj = {
  someKey: 1,
  outer: function() {
    function inner() {      // enlace DIRECTO
       console.log(this);   // apunta al objeto GLOBAL
    }
    inner();
  },
}
obj.outer(); // enlace IMPLÍCITO
```

## 2B. ==SEPARADO del objeto:==
```javascript
function myFunction() {
  console.log(this);
}
const obj = { someKey: 1, myFunction: myFunction }

const newFunction = obj.myFunction;
newFunction();     // enlace DIRECTO → this apunta a GLOBAL
obj.myFunction();  // enlace IMPLÍCITO → this apunta a "obj"
```

## 3. ![[Vinculacion explicita]]
## 4. ![[funcion constructora(herencia prototype)]]

## Resumen rápido:
| Cómo se llama | `this` apunta a |
|---|---|
| `funcion()` | `window` / `global` |
| `objeto.metodo()` | el objeto |
| `new Funcion()` | la nueva instancia |
| `.call(obj)` / `.apply(obj)` / `.bind(obj)` | `obj` |
| Función flecha `=>` | `this` del contexto exterior (léxico) |

> [!tip]
> Las funciones flecha **no tienen su propio `this`**: heredan el del contexto donde fueron definidas. Por eso son útiles en callbacks pero no sirven como métodos de objetos.

---
