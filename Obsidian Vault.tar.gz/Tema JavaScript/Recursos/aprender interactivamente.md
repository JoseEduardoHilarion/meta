[edabit](https://edabit.com/challenge/ARr5tA458o2tC9FTN)

[codewars](https://www.codewars.com/)

---