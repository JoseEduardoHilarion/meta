1. **¿Cuáles de estos tipos no son datos primitivos en JavaScript?**

	Tu respuesta
	
	array

2. **Escoge las respuestas incorrectas. ¿Cuál es la diferencia entre == y === en JavaScript?**

	Tu respuesta
	
	 El primero es igual y el segundo es igualito
	
	 == compara números y === compara strings

3. **Explica la coerción de tipos en JavaScript**  

	Tu respuesta
	
	 La coerción de texto sucede también al sumar diferentes tipos. Los tipos cambian a texto en este ejemplo: var x = 6; var y = "6"; x + y // retorna "66"

4. **¿Qué es hoisting?**  

	Tu respuesta
	
	 Es el espacio físico donde se publican tus proyectos web.
	
	==Respuesta correcta==
	
	 Es un comportamiento predeterminado de JavaScript donde todas las declaraciones de variables y funciones se mueven hacia arriba.

5. **Escoge las respuestas que son verdaderas sobre JavaScript:**  
	Tu respuesta
	
	 En JavaScript, los tipos de datos primitivos se pasan por valor y los tipos de datos no primitivos se pasan por referencia.
	
	 En JavaScript, el alcance nos permitirá saber en una parte determinada del código, cuáles son las variables y funciones a las que podemos o no acceder.
	
	==Respuesta correcta==
	
	 JavaScript es un lenguaje escrito dinámicamente. En un lenguaje escrito dinámicamente, el tipo de una variable se verifica durante el tiempo de ejecución en contraste con el lenguaje escrito estáticamente, donde el tipo de una variable se verifica durante el tiempo de compilación.
	
	 En JavaScript, los tipos de datos primitivos se pasan por valor y los tipos de datos no primitivos se pasan por referencia.
	
	 En JavaScript, el alcance nos permitirá saber en una parte determinada del código, cuáles son las variables y funciones a las que podemos o no acceder.

6. **Escoge las respuestas correctas sobre NaN**   

	Tu respuesta
	
	 NaN representa el valor "No es un número" e indica un valor que no es un número legal.
	
	 Para verificar si un valor es NaN, usamos la función isNaN().
	
	==Respuesta correcta==
	
	 NaN representa el valor "No es un número" e indica un valor que no es un número legal.
	
	 typeof de un NaN devolverá un Número.
	
	 Para verificar si un valor es NaN, usamos la función isNaN().

7. **¿Qué es una función invocada inmediatamente en JavaScript?** 

	Tu respuesta
	
	 Una función invocada inmediatamente (conocida como IIFE) es una función que se ejecuta tan pronto como se define.

8. **¿Qué son las funciones de orden superior en JavaScript?**   

	Tu respuesta
	
	 Las funciones que operan en otras funciones, ya sea tomándolas como argumentos o devolviéndolas, se denominan funciones de orden superior.
	
	==Respuesta correcta==
	
	 Las funciones que operan en otras funciones, ya sea tomándolas como argumentos o devolviéndolas, se denominan funciones de orden superior.
	
	 Un ejemplo es: ordenSuperior(function() { console.log("Hola Mundo") });

9. **¿Qué es "this" en JavaScript?**  

	Tu respuesta
	
	 La palabra clave "this" se refiere al objeto del que la función es una propiedad. El valor de la palabra clave "this" siempre dependerá del objeto que invoca la función.

10. **¿Cuales de estas funciones retornaran verdadero?**   

	Tu respuesta
	
	 "0" == 0
	
	 !"texto" == false
	
	==Respuesta correcta==
	
	 "0" == 0
	
	 !!"texto" == true
	
	 !"texto" == false
	
---