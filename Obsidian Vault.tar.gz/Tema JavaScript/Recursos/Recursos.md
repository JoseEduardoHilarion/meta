[Español: mozilla](https://developer.mozilla.org/es/docs/Web/JavaScript)

[Inglés: mozilla](https://developer.mozilla.org/en-US/docs/Web/JavaScript)

[compatibilidad de funcionalidades de JavaScript](https://caniuse.com/)

[ECMAScript](https://www.ecma-international.org/publications-and-standards/standards/ecma-262/)

![[Hoja de trucos de JavaScript]]
![[Evaluacion]]
![[Evitar bloqueos]]
![[aprender interactivamente]]

---
