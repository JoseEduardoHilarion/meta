|  Operador | Nombre  |Comportamiento   |Uso recomendado|
|---|---|---|---|
|`==`|Igualdad abstracta|Compara el valor, realiza coerción de tipo.|Generalmente no se recomienda.|
|`===`|Igualdad estricta|Compara el valor y el tipo.|**Siempre** preferible, ya que evita sorpresas.|
> [!tip]
> para comparar dos string primero lleva a **mayuscula** y luego compara. 
> 
> Los tipos primitivos (como números y cadenas) se comparan por **valor**, mientras que los objetos (como listas y fechas) se comparan por **referencia**.

---