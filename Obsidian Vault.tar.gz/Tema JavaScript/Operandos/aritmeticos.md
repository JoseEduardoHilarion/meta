|  Operador | Nombre  |Ejemplo   | Descripción  |
|---|---|---|---|
|+|Adición|x + y|Suma dos valores.|
|-|Sustracción|x - y|Resta el segundo valor del primero.|
|*|Multiplicación|x * y|Multiplica dos valores.|
|/|División|x / y|Divide el primer valor entre el segundo.|
|%|Módulo|x % y|Devuelve el resto de una división.|
|**|Exponenciación|x ** y|Eleva el primer valor a la potencia del segundo.|
|++|Incremento|x++ o ++x|Aumenta el valor de una variable en 1.|
|--|Decremento|x-- o --x|Disminuye el valor de una variable en 1.|

---