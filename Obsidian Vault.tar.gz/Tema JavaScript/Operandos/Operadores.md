![[aritmeticos]]
![[comparacion]]
![[logicos]]