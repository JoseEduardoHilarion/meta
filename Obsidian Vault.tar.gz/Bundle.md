### 📊 Cuadro de referencia rápida para el peso del Bundle (JS)

|**Peso del JS (Comprimido/Gzip)**|**Impacto real en la Web Actual (2026)**|**¿Cuándo aplicarlo?**|
|---|---|---|
|**Menos de 100 KB**|**Instantáneo.** Carga en menos de 0.1 segundos incluso en móviles lentos o 4Débil.|_Ideal para sitios pequeños, landing pages o apps iniciales._ No necesitas dividir nada.|
|**Entre 100 KB y 300 KB**|**Muy bueno / Aceptable.** Carga casi imperceptible (0.2 a 0.5 segundos).|_El estándar saludable_ para la mayoría de aplicaciones web medianas en su carga inicial.|
|**Entre 300 KB y 500 KB**|**Zona de precaución.** Empieza a latir la espera en conexiones móviles promedio.|Momento exacto en el que **empezar a usar Lazy Loading** para separar secciones secundarias.|
|**Más de 500 KB**|**Alerta roja.** La app se sentirá pesada, con segundos de pantalla en blanco en móviles.|Obligatorio aplicar **Code Splitting agresivo** por rutas y diferir componentes pesados (gráficos, editores, etc.).|

### ¿Cómo se calcula esto mentalmente con las matemáticas de internet?

Para hacer cuentas rápidas, debes recordar que en la industria el peso de los archivos web se mide en **KB (Kilobytes) o MB (Megabytes)**, pero las conexiones de internet se miden en **Mbps (Megabits por segundo)**.

> _Regla de oro:_ **1 Megabyte (MB) = 8 Megabits (Mb)**.
> 
> Por lo tanto, un archivo de **1 MB** tarda 1 segundo en descargarse en una conexión real de 8 Mbps.

En 2026, aunque el 5G y la fibra óptica vuelan, la realidad móvil global y las latencias hacen que la regla de oro de los ingenieros de rendimiento sea: **intentar que el paquete inicial de JavaScript (First Load JS) NUNCA supere los 200 KB comprimidos**.

Si mantienes tu código inicial por debajo de esa barrera, tu aplicación va a volar en cualquier dispositivo del planeta sin necesidad de volverte loco optimizando antes de tiempo. ¡Anotate esa cifra (200 KB) como tu brújula mental!