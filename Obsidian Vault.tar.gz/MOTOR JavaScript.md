# (Ultra Resumen Técnico)

## 1️⃣ Web APIs Clave
- document.querySelector()
- addEventListener()
- fetch()
- localStorage
- performance.now()

---

## 2️⃣ Medición de Rendimiento

- performance.now()

Uso:
- Guardar tiempo inicial
- Ejecutar función
- Guardar tiempo final
- Restar

Objetivo:
Medir antes de optimizar

---

## 3️⃣ Regla de Oro del DOM

❌ NO modificar el DOM dentro de loops  
✅ Construir primero, insertar después  

---

## 4️⃣ Renderizado Rápido

### Opción simple
- array.map()
- .join('')
- element.innerHTML = ...

1 solo render

---

## 5️⃣ Optimización Real

### DocumentFragment

Pasos:
1. document.createDocumentFragment()
2. createElement()
3. fragment.appendChild()
4. contenedor.appendChild(fragment)

Resultado:
1 solo acceso al DOM

---

## 🔥 Principio Profesional

- Minimizar reflows
- Minimizar repaints
- Minimizar accesos al DOM
- Medir siempre con performance.now()