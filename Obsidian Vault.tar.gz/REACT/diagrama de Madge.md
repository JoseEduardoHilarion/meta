1. ## Los nodos

	Cada nodo es **un archivo** de tu proyecto. El texto dentro es la ruta relativa, ej: `components/Header.jsx`.
	
	💡 Truco: abre el archivo `deps.svg` con un editor de texto y busca `<title>` → ahí está el nombre completo de cada nodo.

2. ## Las flechas

	La flecha **A → B** significa: _"A `import` a B"_. 

3. ## Los niveles (las "capas" que ves)

	Graphviz organiza por profundidad de dependencias:
	
	|Nivel|Qué suele ser|
	|---|---|
	|1er nivel|El punto de entrada (`index.tsx` / `App.jsx`)|
	|2º nivel|Lo que importa directamente (rutas, páginas, providers)|
	|3er nivel|Componentes y lógica intermedia|
	|4º nivel (el más profundo)|Utilidades, helpers, componentes hoja|

4. ## Los colores

	- 🟢 **Verde**: archivos que **no importan nada** del proyecto (hojas, el final de la cadena)
	- 🔵 **Azul**: archivos normales que sí importan a otros
	- 🔴 **Rojo**: ⚠️ archivos en una **dependencia circular** (A importa a B y B importa a A) — esto suele ser un problema de arquitectura que conviene arreglar

## 🧠 Cómo leerlo como un pro

1. **Busca el nodo con más flechas entrando** → ese es el código más reutilizado del proyecto (suele ser utils, contexto, o un componente base).
2. **Si ves nodos rojos**, ejecuta esto para listar exactamente cuáles son:

```bash
   pnpm dlx madge --circular src/
```

3. **Cadenas muy largas** (muchos niveles) pueden indicar acoplamiento excesivo.
	Eso sería una cadena de ~9 niveles. Cada flecha es un `import`.
	```
	index.tsx → App → Router → Pagina → Layout → Seccion → Tarjeta → Boton → Icono
	```

	¿Por qué puede ser un problema?

	1. **Acoplamiento**: si cambias algo en el eslabón final, el efecto viaja por toda la cadena.
	2. **Difícil de seguir**: para entender por qué se renderiza un componente tienes que atravesar 8 archivos.
	3. **Prop drilling**: muchas veces esas cadenas largas son componentes que solo pasan props hacia abajo sin hacer nada más:

	4. **Archivos "re-exportadores"**: a veces los niveles extra son archivos que solo hacen:     
	```js
	    export { default } from './real-component'
	```
    
	## ¿Cuándo preocuparse?

	|Niveles|Lectura|
	|---|---|
	|**3–5**|✅ Normal y saludable (tu caso: 4)|
	|**6–7**|🤔 Revisable, depende del tamaño del proyecto|
	|**8+**|⚠️ Señal de alerta: probable exceso de intermediario|

---
