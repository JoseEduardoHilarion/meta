## El Congelador de Funciones 🔒

Cada vez que un componente se re-renderiza, **todas sus funciones flecha se recrean** en memoria (nuevo puntero). Esto rompe [[React.memo]] porque el hijo ve una "nueva" función aunque haga lo mismo.

`useCallback` devuelve siempre el **mismo puntero** de una función mientras sus dependencias no cambien.

## Sintaxis

```jsx
const funcionMemorizada = useCallback(() => {
  // lógica
}, [dependencias]);
```

## Ejemplo sin vs con useCallback

```jsx
// ❌ Sin useCallback — HijoPesado siempre se re-renderiza
function Padre() {
  const [contador, setContador] = useState(0);

  const handleClick = () => console.log("click"); // nuevo puntero en cada render

  return (
    <>
      <button onClick={() => setContador(c => c + 1)}>+</button>
      <HijoPesado onClick={handleClick} /> {/* React.memo no sirve aquí */}
    </>
  );
}

// ✅ Con useCallback — HijoPesado solo se re-renderiza si handleClick cambia
function Padre() {
  const [contador, setContador] = useState(0);

  const handleClick = useCallback(() => {
    console.log("click");
  }, []); // Sin dependencias: se crea una sola vez

  return (
    <>
      <button onClick={() => setContador(c => c + 1)}>+</button>
      <HijoPesado onClick={handleClick} /> {/* React.memo funciona correctamente */}
    </>
  );
}

const HijoPesado = React.memo(function HijoPesado({ onClick }) {
  console.log("HijoPesado renderizado");
  return <button onClick={onClick}>Acción pesada</button>;
});
```

## Cuándo usarlo (y cuándo NO)

| Usarlo ✅ | No usarlo ❌ |
|---|---|
| La función se pasa como prop a un hijo con `React.memo` | En funciones que no se pasan como props |
| La función es dependencia de un `useEffect` | En componentes simples sin problemas de rendimiento |
| La función se recrea en cada render y es costosa | Por defecto en todo — tiene su propio overhead |

> [!NOTE] `useCallback(fn, deps)` es equivalente a `useMemo(() => fn, deps)`. `useMemo` memoriza el **resultado** de una función; `useCallback` memoriza la **función misma**.

## Relaciones
- [[React.memo]] — sin `useCallback`, `React.memo` falla con funciones como props.

---
