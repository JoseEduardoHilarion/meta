## El Problema

Si el **Padre** se re-renderiza, por defecto todos sus **Hijos** también lo hacen (Cascada). Pero si un Hijo es muy pesado y sus **Props** no cambiaron, podemos usar un "Guardia".

#### A. ¿Qué hace el Guardia?

`React.memo` es una [[HOC (Higher-Order Component)]] que envuelve al componente Hijo. Su trabajo es hacer una **Comparación Superficial (Shallow Comparison)** de las props antes de dejar pasar la ejecución.

- **Lógica Interna:** 
	1. El Padre intenta renderizar al Hijo. 
	2. El "Guardia" intercepta la orden y compara los punteros: `¿propVieja === propNueva?`. 
	3. **Resultado A:** Si los punteros son iguales, el Guardia dice: _"No entres, devolvé el mismo racimo de objetos que ya teníamos"_ (ahorra CPU). 
	4. **Resultado B:** Si al menos un puntero cambió, el Guardia deja pasar la ejecución y el Hijo se re-renderiza.
    

#### B. El Peligro de las Funciones Flecha

Aquí es donde tu nota sobre **"Nuevos Punteros"** es clave. Si le pasás al Hijo una función flecha declarada dentro del cuerpo del Padre:

```jsx
// En el Padre — ❌ Rompe React.memo
<Hijo onClick={() => console.log("click")} /> 
```

Como esa función se crea de nuevo en cada render (nuevo puntero), el `React.memo` del Hijo dirá: _"Epa, el puntero cambió, tengo que renderizar"_. **El Guardia falla porque el programador creó un puntero nuevo sin necesidad.**

```jsx
// ✅ Solución: useCallback "congela" el puntero de la función
const handleClick = useCallback(() => {
  console.log("click");
}, []); // Solo se crea una vez

<Hijo onClick={handleClick} />
```

> **Ver:** [[useCallback]] para entender cómo "congelar" funciones y hacer que `React.memo` funcione correctamente.

#### C. Uso correcto

```jsx
// Envolvés el componente hijo con React.memo
const HijoPesado = React.memo(function HijoPesado({ valor }) {
  return <div>{/* procesamiento costoso */}{valor}</div>;
});
```

## Resumen:

- **Sin Memo:** El Padre cambia → El Hijo se re-calcula siempre (Gasto de RAM/CPU).
    
- **Con Memo:** El Padre cambia → El Hijo solo se re-calcula si sus "cables" (Props) apuntan a una dirección de memoria distinta.

> [!WARNING] No uses `React.memo` en todos los componentes por defecto. Solo tiene sentido cuando el componente es **costoso de renderizar** y sus props cambian con poca frecuencia. El overhead de comparar punteros en componentes simples puede ser mayor que el render mismo.
    

---
