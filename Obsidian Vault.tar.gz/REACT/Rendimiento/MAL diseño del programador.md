```jsx
import { useState, useEffect } from "react";
function DemoIntervalRapido() {
  const [contador, setContador] = useState(0);
  useEffect(() => {
    // Intervalo muy rápido: cada 10ms
    const intervalo = setInterval(() => {
      setContador((prev) => prev + 1);//React recibe CIENTOS de llamadas a `setState` por segundo.
    }, 10);
    return () => clearInterval(intervalo);
  }, []);
  return <p>Contador: {contador}</p>;
}

```

### Qué pasa aquí

- El programador puso un intervalo de **10ms**, lo cual es excesivo.
    
- React recibe cientos de llamadas a `setState` por segundo.
    
- En vanilla JS, esto podría bloquear la UI porque cada actualización intentaría repintar.
    
- En React, gracias al **batching**, muchas de esas actualizaciones se agrupan y se procesan juntas en el próximo ciclo de render.
    
- Resultado: la UI sigue fluida, pero el diseño es ineficiente y poco elegante.
    



> [!NOTE] 👉 Entonces:
> - Sí, es un **problema de diseño del programador**.
> - React lo mitiga, pero no lo soluciona mágicamente: sigue siendo mejor usar un intervalo razonable (ej. 1000ms) o técnicas como _throttling_ y _debouncing_.

---