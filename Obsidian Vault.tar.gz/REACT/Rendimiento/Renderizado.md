### 🔎 Orden simplificado del ciclo
1. **[[Call Stack]]**: corre tu función, llega a `setContador`.    
2. React encola la actualización en su **scheduler interno**.    
3. Se ejecutan [[Microtask Queue]] pendientes (promesas).    
4. Se ejecutan [[Macrotasks Callback Queue]] pendientes (timers, eventos).    
5. **Renderizado/pintado**: React decide si aplicar las actualizaciones ahora o esperar.(**Scheduling**)
	- Si puede, renderiza en esta vuelta.    
	- Si no, las deja para la próxima vuelta del loop.    
6. Después del paint → se ejecutan los [[useEffect]].

> [!NOTE] 👉 En resumen:
> - SI, React también tiene ese problema: no puede usar la fase de [[Tema DOM/Motor JavaScript/Renderizado|Renderizado]] todo el tiempo.
> - Por eso implementa su propio **sistema de prioridades y batching**.
> - `setState` no es una [[Microtask Queue]] ni una [[Macrotasks Callback Queue]], sino una actualización que React programa para el próximo render, y si no puede, la pasa a la siguiente vuelta del [[Event Loop]].

> [!NOTE] 👉 React agrega una capa de inteligencia:
> - **Batching**: si llamás varias veces a `setState` en el mismo ciclo, React las agrupa y hace un solo render.
> - **Scheduling**: si hay demasiadas actualizaciones, React puede decidir esperar al próximo “tick” del event loop o al próximo “paint” del navegador.
> - **Prioridades**: con el modo concurrente, React distingue entre actualizaciones urgentes (ej. escribir en un input) y actualizaciones menos críticas (ej. animaciones, datos de fondo). Las urgentes se procesan primero, las otras pueden esperar.

---