
---

## 🧱 Fundamentos:
- ### Conceptos
	- [[Internamente React]] 🛠️
	- [[Componentes]] 
		- [[JSX]] 
		- [[REACT/Ciclo de Vida y Efectos/Ciclo de vida|Ciclo de vida]]
	- [[Declarativo vs. Imperativo]]
	- [[Inmutabilidad]]
	
- ### CSS
	- [[React vs CSS]] => [[BEM + Nesting]]
	- [[Fundamentos CSS Moderno]]
	- [[debugging CSS|debugging CSS]]
- [[Estructura de Carpetas]]
- [[Legacy]]

---

## Gestión de Datos:

- ### Estado 💧
	 - [[useState]]
		 - [[Setters en useState]]
		 - [[Batching consecuencia la Atomicidad]]
	 - [[useReducer]]
- ### Datos Globales 🌐
	- [[Prop Drilling]]
	- [[Proveedor (Context API)]]
	
- ### Comunicación 📡
	- [[Props]]
	- [[Desestructuración]]
	- [[Elevar el Estado]]
	- [[Container & Presentational]]
	- [[useRef]]
- ### Arquitectura
	- [[Si Composición, NO Herencia]]
	- [[Patrones REACT]] 
---

## Efectos Secundarios
- [[useEffect]] 🔄
- [[useLayoutEffect]] ⏱️

---

## ⚡ Rendimiento:
- [[React.memo]] 🛡️
- [[useCallback]] 🔒
- [[REACT/Rendimiento/Renderizado|Renderizado]] ⚡
- [[MAL diseño del programador]]
- [[Bundle]] 


## Test:
- [[Unitarios]]
- [[Integración]]
- [[End to end (E2E)]]
---
