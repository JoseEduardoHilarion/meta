## El Problema 🚩
```jsx
// user vive en App pero lo necesita UserCard
// Para llegar tiene que pasar por Layout y Sidebar aunque no lo usen

function App() {
  const user = { nombre: 'Jose' };
  return <Layout user={user} />;
}
function Layout({ user }) {// ❌ Layout no usa user — solo lo pasa  
  return <Sidebar user={user} />;
}
function Sidebar({ user }) {// ❌ Sidebar no usa user — solo lo pasa  
  return <UserCard user={user} />;
}
function UserCard({ user }) {// ✅ Este sí lo usa  
  return <h2>{user.nombre}</h2>;
}
```
1. **Código sucio**: Los componentes intermedios se llenan de props que no les pertenecen.
2. **Dificultad de mantenimiento**: Si cambias el nombre de una prop en la cima, tienes que renombrarla en todos los niveles intermedios.
3. **Acoplamiento innecesario**: Los componentes dejan de ser "tontos" y reutilizables porque dependen de datos que solo sus hijos necesitan.


## Solución (Refactorización) 🚀
1. [[Composicion Prop children y o Slots]].
2. **[[Proveedor (Context API)]]**: Crear un "túnel" directo desde el Abuelo al Nieto, para datos globales.
3. **Estado Global**: Librerías como [[Zustand]] o Redux.

---
