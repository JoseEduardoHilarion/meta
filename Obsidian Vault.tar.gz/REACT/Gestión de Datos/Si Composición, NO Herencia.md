Todos estos Patroes son de composición:

- [[Proveedor (Context API)]]  → composición con children
- [[HOC (Higher-Order Component)]] → composición de funciones (función que envuelve componente)
- [[Render Props]] → composición delegando el JSX
- [[Container & Presentational]] → composición de responsabilidades


---
**HERENCIA — cómo se hace en OOP clásico**
En Java, C++ o Python extendés una clase para agregar comportamiento:

```js
// OOP clásico
class Boton {
  render() { return '<button>click</button>'; }
}
class BotonPrimario extends Boton {
  render() { return '<button class="primary">click</button>'; }
}
class BotonPrimarioGrande extends BotonPrimario {
  render() { return '<button class="primary large">click</button>'; }
}
```

---

**El problema cuando intentás lo mismo en React**. Imaginá que tenés una `Card` y querés variantes. Con herencia:

```
Card
├── CardConHeader
│   ├── CardConHeaderYFooter
│   ├── CardConHeaderYImagen
│   └── CardConHeaderImagenYFooter
├── CardConFooter
│   └── CardConFooterYImagen
└── CardConImagen
```

Cada combinación nueva es una clase nueva. Con 4 variantes posibles tenés potencialmente 16 subclases. Se llama **explosión combinatoria** — el árbol de herencia crece sin control.

Y el problema más profundo: si cambiás `Card`, todas las subclases se ven afectadas aunque no quieran.

---

**COMPOSICION — cómo lo resuelve React**

En vez de extender, **combinás componentes**. Un solo `Card` flexible:

```jsx
// ✅ Un componente, todas las combinaciones posibles
function Card({ children }) {
  return <div className="card">{children}</div>;
}
function CardHeader({ children }) {
  return <div className="card-header">{children}</div>;
}
function CardBody({ children }) {
  return <div className="card-body">{children}</div>;
}
function CardFooter({ children }) {
  return <div className="card-footer">{children}</div>;
}
// Armás la combinación que necesitás en el momento
<Card>
  <CardHeader>Título</CardHeader>
  <CardBody>Contenido</CardBody>
</Card>
<Card>
  <CardHeader>Título</CardHeader>
  <CardBody>Contenido</CardBody>
  <CardFooter>Acciones</CardFooter>
</Card>
<Card>
  <CardBody>Solo contenido, sin header ni footer</CardBody>
</Card>
```

No hay subclases. Cada pieza es independiente. Las combinaciones son infinitas.
[[Composicion Prop children y o Slots]]

---

**La diferencia mental clave**

```
Herencia:     BotonPrimario  ES-UN  Boton
Composición:  BotonPrimario  USA    Boton
```

---

**¿Cuándo usarías herencia entonces?**

En React prácticamente NUNCA.

Si te encontrás pensando _"necesito extender este componente"_, la respuesta casi siempre es _"necesito un prop más, un children, o un hook"_.

---
