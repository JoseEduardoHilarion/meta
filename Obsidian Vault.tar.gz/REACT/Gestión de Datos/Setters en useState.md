1. #  Directo: **`setState(valor)`**
- Cuando el nuevo estado es fijo o calculado independientemente del estado anterior (ej. resetear, asignar un número aleatorio, cargar un valor desde la base de datos).
```jsx
    ////////////////////
    const [usuario, setUsuario] = useState({ 
	    nombre: "José Eduardo",
	    edad: 25,
	    puesto: "Programador" 
	});	
	setUsuario({ nombre: 'Ana', edad: 30, puesto: 'Diseñadora' }); 
	// ✅ Cargar desde API (reemplaza todo, no lee estado anterior) 
	setUsuario(datosDeAPI);
	////////////////////
	const [carrito, setCarrito] = useState(["producto1", "producto2"]);
	setCarrito([]);// Vaciar carrito
	////////////////////////
	setCarrito(productosDeLaAPI);
	//reemplaza todo el carrito con los productos que vienen de una API externa.
```

2. # Funcional: **`setState(prev => ...)`**
- cuando el nuevo estado se construye a partir del estado anterior (ej. sumar, restar, multiplicar, concatenar).
```jsx
	function handleClick(i) {
        // 1. Si NO "hay ganador" Y la celda "NO tiene algo"
        if (!winner && !squares[i].data) {
            const nextSquares = squares.map((item, index) => 
                index === i ? 
                    { ...item, data: xIsNext ? 'X' : 'O' } 
                    : item
            );
            // 3. Ejecutamos la función de juego
            onPlay(nextSquares, xIsNext ? 'X' : 'O');            
        }        
    }

	setTareas(prev => [...prev, nuevaTarea]);
	
	//incrementar la edad en base al valor actual
	setUsuario(prev => ({ ...prev, edad: prev.edad + 1 }));
	// ✅ Así — depende del estado anterior para preservar el resto 
	setUsuario(prev => ({ ...prev, edad: 26 }));	
	
	//elimina solo el último producto del carrito
	setCarrito(prev => prev.slice(0, -1));
	
	//borre un producto específico del carrito según su `id`
	setCarrito(prev => prev.filter(producto => producto.id !== idAEliminar));
	
	//ordene el carrito por precio ascendente
	setCarrito(prev => [...prev].sort((a, b) => a.precio - b.precio));

	//incrementar el contador solo si es menor que 10
	setContador(prev => {
	if (prev < 10) {
	    return prev + 1;
	}
	return prev; // si ya es 10 o más, no cambia
	});

	//limite el carrito a un máximo de 5 productos
	setCarrito(prev => {
	 if (prev.length < 5) {
	    return [...prev, nuevoProducto];
	 }
	 return prev; // si ya hay 5, no agrega nada
	 });

	//sume 10 puntos solo si el usuario ya tiene más de 50
	setPerfil(prev => {
	if (prev.puntos > 50) {
	   return { ...prev, puntos: prev.puntos + 10 };
	}
	return prev; // si tiene 50 o menos, no cambia
	});

	//actualice solo los puntos del perfil con el valor que viene de la API, pero mantenga el nombre actual.
	setPerfil(prev => ({
	  ...prev,
	  puntos: prev.puntos > 50 ? valorDeLaAPI : prev.puntos
	}));
```


3. ## [[Setters Pureza]]

---
