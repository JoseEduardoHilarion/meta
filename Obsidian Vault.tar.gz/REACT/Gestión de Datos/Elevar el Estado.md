## Lifting State Up [[Inversion of Control - IoC]]
Cuando dos o mas componentes necesitan compartir datos, el estado de cada componente hijo se "ELEVA" al padre común, para que la información fluya hacia abajo mediante [[Props]].

- No elevamos el _componente_ entero, sino la **variable** (el `useState` de cada componente hijo).
    
- El estado vive en el padre, y el hijo solo lo "mira" a través de las props. Cuando el hijo ejecuta el callback [[Props]](Funcion), el estado cambia en el padre y la nueva información "baja" de nuevo al hijo.

---
