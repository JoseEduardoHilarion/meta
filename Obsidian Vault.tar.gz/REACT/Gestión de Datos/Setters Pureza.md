
```
  ✅ Recibe prev, devuelve estado nuevo
  ✅ No modifica prev — siempre crea un valor nuevo
  ✅ No hace fetch, console.log, ni modifica variables externas
  ✅ Mismo prev siempre → mismo resultado

React llama el setter DOS VECES en desarrollo (StrictMode)
para detectar impurezas. Si el resultado es idéntico → puro ✅
```


```js
// ✅ Pura — mismo input, mismo output, no toca nada externo
const doble = (n) => n * 2;

// ❌ Impura — depende de algo externo que puede cambiar
let factor = 2;
const doble = (n) => n * factor; // si factor cambia, el resultado cambia
```

---

**Por qué React exige que los setters sean puros**

React en modo desarrollo llama la función del setter **dos veces** para detectar impurezas.
```jsx
// React hace esto internamente en StrictMode:
setContador(prev => prev + 1); // llamada 1: prev=0 → devuelve 1
setContador(prev => prev + 1); // llamada 2: prev=0 → devuelve 1 ← idéntico ✅
// Con una función impura:
setContador(prev => {
  console.log('ejecutando'); // aparece DOS veces en consola ← señal de impureza
  return prev + 1;
});
```

---

**Las tres formas de romper la pureza en un setter**

**1. Mutación — modificar `prev` en lugar de crear uno nuevo**

```jsx
// ❌ Muta el array original — mismo objeto, React no detecta el cambio
setCarrito(prev => {
  prev.push(nuevoProducto); // mutación directa
  return prev;              // devuelve el mismo array → React no re-renderiza
});
// ✅ Crea un array nuevo
setCarrito(prev => [...prev, nuevoProducto]);
// ❌ sort() muta el array en el lugar
setCarrito(prev => prev.sort((a, b) => a.precio - b.precio));
// ✅ Spread antes de sort — ya lo hacías bien en tus notas
setCarrito(prev => [...prev].sort((a, b) => a.precio - b.precio));
```

**2. Efectos secundarios — hacer algo además de calcular el nuevo estado**

```jsx
// ❌ Fetch dentro de un setter — efecto secundario
setNotas(prev => {
  fetch('/api/log'); // ← no va acá
  return [...prev, nuevaNota];
});
// ❌ Modificar algo externo
let contador = 0;
setValor(prev => {
  contador++; // modifica variable externa
  return prev + 1;
});
// ✅ Solo transforma y devuelve
setNotas(prev => [...prev, nuevaNota]);
// Los efectos secundarios van en useEffect o en el event handler
```

**3. Depender de algo externo que puede cambiar entre llamadas**

```jsx
// ❌ Si precio cambia entre la llamada 1 y la llamada 2 de React, 
//    los resultados son distintos → impuro
setTotal(prev => prev + precio); // precio viene del closure
// ✅ Todo lo que necesitás debería estar en prev
// Si necesitás datos externos, calculá antes y pasalos directamente:
const nuevoTotal = totalActual + precio;
setTotal(nuevoTotal); // forma directa — no hay closure problemático
```

---

**Ejemplos puro :s** [[Setters en useState]]

---
