Se definen directamente en los argumentos de la función. Extrae las propiedades del objeto `props` directamente.

## Por qué usarla:
1. **Legibilidad:** Actúa como un "contrato" o documentación visual.
2. **Valores por defecto:** Permite definir `prop = 'valor'` fácilmente.
3. **Limpieza:** Evita repetir la palabra `props.` en todo el JSX.

```jsx
//❌ Estilo Antiguo (Prop Object)
function Usuario(props) {
  return <h1>Hola, {props.nombre}</h1>;
}
// Definición directa en la desestructuración NUEVO
const Boton = ({ 
	color = 'blue', 
	texto = 'Enviar', 
	deshabilitado = false 
}) => { 
	return <button className={color} disabled={deshabilitado}>{texto}</button>; };
```

---
