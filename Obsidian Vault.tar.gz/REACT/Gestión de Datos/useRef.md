El valor **persiste entre renders** pero **cambiar el valor no dispara un re-render**. Devuelve un objeto con una única propiedad: `.current`.

```jsx
const algo = useRef(valorInicial); 
algo.current // acá vivie el valor 
algo.current = nuevoValor // así se cambia — NO dispara re-render
```


**Uso 1 — acceder directamente a un nodo del DOM**

```jsx
function FormLogin() {
  const inputRef = useRef(null);
  useEffect(() => {
    inputRef.current.focus(); // acción directa sobre el elemento del DOM
  }, []);
  return (
      <input ref={inputRef} type="email" placeholder="Email" />    
  );
}
```

`ref={inputRef}` le dice a React: _"cuando montes este input, guardá su nodo del DOM en `inputRef.current`"_. Después podés llamar cualquier método nativo del DOM — `focus()`, `blur()`, `scrollIntoView()`, etc.

---

**Uso 2 — guardar un valor que persiste sin causar re-renders**

El caso más común: guardar el ID de un `setInterval` para poder limpiarlo:
```jsx
function Cronometro() {
  const [tiempo, setTiempo] = useState(0);
  const timerRef = useRef(null); // guarda el ID del intervalo
  const iniciar = () => {
    timerRef.current = setInterval(() => {
      setTiempo(prev => prev + 1);
    }, 1000);
  };
  const detener = () => {
    clearInterval(timerRef.current); // usa el ID guardado
  };
  return (
    <div>
      <p>{tiempo}s</p>
      <button onClick={iniciar}>Iniciar</button>
      <button onClick={detener}>Detener</button>
    </div>
  );
}
```

Si guardaras el ID en un `useState`, cada vez que se actualizara dispararía un re-render innecesario. Con `useRef` lo guardás silenciosamente.

---

**La regla para decidir:**

```
¿Necesitás que el cambio actualice la pantalla?
  → useState

¿Necesitás guardar un valor entre renders sin tocar la pantalla?
  → useRef
¿Necesitás manipular un elemento del DOM directamente?
  → useRef con el prop ref={...}
```

Caso de uso : [[Formularios Controlados vs. No Controlados]]

---
