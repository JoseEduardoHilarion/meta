- **Imperativo:** Decirle al programa _cómo_ hacer algo (paso a paso).

- **Declarativo:** Decirle al programa _qué_ queremos ver (el resultado final).
	- **En React:** Definimos la interfaz en función del estado y dejamos que React sincronice el DOM.


|**Situación**|**Enfoque Imperativo (Evitar)**|**Enfoque Declarativo (Recomendado)**|
|---|---|---|
|**Modificar lista**|`copia = [...]; copia[i] = val;`|`lista.map(item => ...)`|
|**Calcular valor**|`useState` para el resultado|`const valor = calculo(estado)`|
|**Sincronización**|`useEffect` para copiar estados|Elevar estado al padre|
|**Cambios de UI**|`element.classList.add(...)`|`className={isActive ? 'activo' : ''}`|


> [!NOTE] Estado -> Render -> Evento -> Update -> Estado
> es el ciclo infinito de React. Cada vez que logras que ese ciclo sea **inmutable** y **declarativo**, tu aplicación se vuelve mucho más predecible y fácil de depurar.

---
