1. ### Controlados (Recomendado [[useState]])
El valor del input siempre está sincronizado con el estado de React. **Ventaja**: Validación en tiempo real, deshabilitar botones instantáneamente, formatos automáticos.

2. ### NO Controlados (Caso de uso de [[useRef]] )
El valor vive en el DOM y solo lo "leemos" cuando lo necesitamos (ej. al enviar el form). **Ventaja**: Menos re-renderizados (mejor rendimiento en formularios gigantescos de cientos de campos).

| Característica | Controlado (State) | No Controlado (Ref) |
| :--- | :--- | :--- |
| **Sincronización** | Instantánea | Solo bajo demanda |
| **Rendimiento** | Re-renderiza en cada tecla | No re-renderiza |
| **Validación** | Sencilla y en vivo | Difícil (hay que esperar al submit) |

3. ### El error común
Intentar usar `useRef` para todo por "comodidad". Si necesitas que un mensaje de error aparezca *mientras* el usuario escribe, **debes** usar `useState`.


---
