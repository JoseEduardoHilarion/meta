**Solución 1: Composición por `children`**

La idea clave: en vez de pasar `user` por cada nivel, creás `UserCard` directamente en `App` donde ya tenés `user`, y lo pasás como `children`:

```jsx
function App() {
  const user = { nombre: 'Jose' };
  return (
    <Layout>
      <Sidebar>
        <UserCard user={user} />  {/* user va directo — sin pasar por Layout ni Sidebar */}
      </Sidebar>
    </Layout>
  );
}

// Layout y Sidebar ahora son contenedores transparentes
function Layout({ children }) {// No sabe nada de user ✅
  return <div className="layout">{children}</div>;  
}
function Sidebar({ children }) {// No sabe nada de user ✅
  return <aside>{children}</aside>;  
}
function UserCard({ user }) {
  return <h2>{user.nombre}</h2>;
}
```

`user` nunca pasa por `Layout` ni `Sidebar`. Va directo de `App` → `UserCard`.

---

**Solución 2: Composición por `Slots` (props nombrados)**

Slots es lo mismo pero con nombres específicos en vez de `children`. Útil cuando tenés múltiples "zonas" de contenido:

```jsx
function App() {
  const user = { nombre: 'Jose' };
  return (
    <Layout
      header={<Header titulo="Mi App" />}
      sidebar={<UserCard user={user} />}  {/* slot nombrado — va directo */}
      footer={<Footer />}
    />
  );
}

// Layout tiene zonas nombradas
function Layout({ header, sidebar, footer }) {
  return (
    <div>
      <header>{header}</header>
      <aside>{sidebar}</aside>
      <footer>{footer}</footer>
    </div>
  ); // Tampoco sabe nada de user ✅
 }
```

---

**La diferencia entre los dos:**

```jsx
<Layout>
  <Algo />/* children — una zona*/
</Layout>

<Layout
  header={<Algo />}// slots — varias zonas
  sidebar={<OtraCosa />}// slots — varias zonas
/>
```

---

**El punto clave que conecta todo esto**

Esto también explica por qué en nuestra `NotasProvider` el `<header>` y `<main>` no re-renderizaban cuando cambiaba el estado — eran `children` creados en `App`, que no re-renderizó. La composición no es solo una solución al prop drilling, también es una optimización de renders.
