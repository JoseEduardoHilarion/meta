**Batching — React agrupa varios setState en un solo re-render**

Sin batching, esto haría 3 re-renders:
```jsx
function handleSubmit() {
  setLoading(true);    // re-render 1
  setError(null);      // re-render 2
  setData(resultado);  // re-render 3
}
```

Con batching, React los agrupa y hace solo 1:

```jsx
function handleSubmit() {
  setLoading(true);    // ⏳ espera...
  setError(null);      // ⏳ espera...
  setData(resultado);  // ⏳ espera...
  // ✅ React aplica los tres juntos → 1 solo re-render
}
```

---

**Atomicidad — la UI nunca ve un estado a medias**

Este es el porqué importa el batching. Sin él, entre el primer y segundo setState la UI estaría en un estado inconsistente:
```jsx
async function cargarNotas() {
  const notas = await fetch('/api/notas');

  // ❌ Sin batching — la UI vería esto por un instante:
  setLoading(false);  // render: loading=false, notas=[] ← pantalla rota
  setNotas(notas);    // render: loading=false, notas=[...] ← correcto

  // ✅ Con batching — la UI va directo al estado correcto:
  setLoading(false);  // agrupa...
  setNotas(notas);    // agrupa... → 1 render con ambos valores ya aplicados
}
```

Atomicidad significa que la UI pasa del estado anterior al estado final sin pasar por estados intermedios rotos.

---

**Dónde aplica el batching — cambia entre React 17 y 18:**

```jsx
// ✅ SIEMPRE batcheó — event handlers de React
<button onClick={() => {
  setA(1); setB(2); setC(3); // 1 render en React 17 y 18
}}>

// ❌ React 17 NO batcheaba — código asíncrono
setTimeout(() => {
  setA(1); // re-render
  setB(2); // re-render
  setC(3); // re-render — 3 renders en React 17
}, 1000);

// ✅ React 18 SÍ batchea — en todos lados automáticamente
setTimeout(() => {
  setA(1); setB(2); setC(3); // 1 render en React 18
}, 1000);
```

React 18 (que es lo que usás con Vite) lo hace automático en cualquier contexto — `setTimeout`, `fetch`, `promises`, eventos nativos del DOM.

---

**`flushSync` — cuando necesitás salir del batching**

En casos muy específicos podés forzar un render inmediato:

```jsx
import { flushSync } from 'react-dom';

function handleClick() {
  flushSync(() => {
    setCount(1); // fuerza un render aquí mismo
  });
  // el DOM ya está actualizado acá
  console.log(document.getElementById('contador').textContent); // "1"

  flushSync(() => {
    setFlag(true); // segundo render
  });
}
```

Esto es raro — lo vas a necesitar cuando necesitás medir el DOM después de un setState, antes de que React lo hubiera batcheado. En la práctica del día a día casi nunca lo usás.

---

## Relacionado
- [[Setters Pureza]]
- [[useState]]
