**De arriba hacia abajo** (unidireccional).

1. ### **Dato:**
	Cuando el Padre se renderiza, en su `return` le pasa al Hijo "piezas" de su propio mundo. Crea un objeto `props` y le mete adentro las variables o punteros que el Padre decidió compartir.
	- > [!NOTE] **Regla de Oro:**
	> **"Si viene de arriba, NO se toca; se pide permiso para cambiarlo"** (`read-only`). Si el Hijo intenta cambiarlas, React no se entera porque no se disparó ningún "Gatillo" (setState) en el Padre. ADEMAS recordar que si la prop es un **objeto** o un **array**, aunque no puedas reasignar la prop, _podrías_ mutar su interior (lo cual rompería React). 	
	```jsx
	//`props` es un objeto que recibe el componente.
	function Saludo(props) {
		return <h1>Hola, {props.nombre}!</h1>; 
		//`props.nombre` accede al valor que le pasamos
	}
	// Uso:
	<Saludo nombre="María" />
	<Saludo nombre="Juan" />
	```

1. ### **Función:**

	¿Cómo hace el Hijo para avisarle al Padre que algo debe cambiar? (Ejemplo: un botón en el Hijo que borra un dato en el Padre). Como no puede tocar las Props, usamos la técnica de **Pasar una Función como Prop**.
	
	1. **En el Padre:** Creas una función que usa el `setEstado`.    
	2. **El Cable:** Le pasas esa función al Hijo como si fuera un dato más.    
	3. **La Ejecución:** El Hijo recibe la función y la guarda en su mundo. Cuando el usuario hace click, el Hijo "tira del cable" (ejecuta la función).    
	4. **El Resultado:** La función se ejecuta en el **ámbito (scope) del Padre**, dispara el `setEstado` del Padre, y todo el ciclo de "Simulación del Mundo" vuelve a empezar desde arriba.  
	5. "Polimorfismo" en React:	
		Como el hijo es **reutilizable**, diferentes padres pueden pasarle funciones (callbacks) totalmente distintas. El hijo **"pisa"** su comportamiento según el contexto.
		
## Ejemplo de "Reescritura":
	
|Contexto|Padre (Director)|Callback enviado al Hijo|Acción Resultante|
|---|---|---|---|
|**App de Finanzas**|`SeccionContable`|`(n) => setSaldo(saldo + n)`|El botón **Suma dinero** 💰|
|**App de Juegos**|`SeccionHeroe`|`(n) => setVida(vida - n)`|El mismo botón **Quita vida** ⚔️|

---