Popularizado en la era de los componentes de clase, consiste en dividir la interfaz en dos capas para separar la **lógica** de la **vista**.

```jsx
const baseUrl = "https://raw.githubusercontent.com/xrochoa/photo-gallery-resources/master/";
const fetchUrl = baseUrl + "json/photos.json";

class ContenedorDeParques extends React.Component {
  constructor() {
    super();
    this.state = {
      parques: []
    };
  }
  componentDidMount() {
    fetch(fetchUrl)
      .then(res => res.json())
      .then(parques => this.setState({ parques }));
  }
  render() {
    return <Parques parques={this.state.parques} />;
  }
}

function Parques({ parques }) {
  const style = { width: '100px' };
  return parques.map(parque => {
    const url = `${baseUrl}/highres/${parque.id}/1.jpg`;
    return <img style={style} src={url} key={parque.id} alt="Parque" />
  });
}
```

### Contenedor (Smart / Inteligente)
   - Maneja el estado (`state`).
   - Realiza las peticiones a APIs (`fetch`, `axios`).
   - **No** contiene estilos ni HTML complejo.
   - Renderiza al componente visual y le pasa los datos por propiedades (`props`).
   - Suelen ser los "Padres" que envuelven a los hijos tontos.
 
### Presentación (Dumb / Tonto)

   - No maneja estado propio (es _stateless_).
   - Recibe todo lo que necesita exclusivamente por `props`. Reciben datos y funciones de callback (como `onLike`).
   - Contiene los estilos, clases CSS y la estructura HTML/JSX.
   - Es altamente reutilizable y fácil de testear (Pruebas Unitarias).

```jsx
const baseUrl = "https://raw.githubusercontent.com/xrochoa/photo-gallery-resources/master/";
const fetchUrl = baseUrl + "json/photos.json";

// 1. COMPONENTE CONTENEDOR
function ContenedorDeParques() {
  // Definimos el estado 'parques' y la función para actualizarlo
  const [parques, setParques] = React.useState([]);

  // useEffect reemplaza a componentDidMount
  React.useEffect(() => {
    fetch(fetchUrl)
      .then(res => res.json())
      .then(data => setParques(data)); 
  }, []); //solo se ejecute UNA VEZ (al montarse)

  return <Parques parques={parques} />;
} 
```

---
Otro ejemplo:`SeccionPorcentajes` y `SeccionClima`
```JSX
// 2. DOMINIO PORCENTAJES (Componente de lógica específica)
function SeccionPorcentajes() {
  const [operacion, setOperacion] = useState('5%');
  const [valor, setValor] = useState(0);
  const manejarCambio = (tipo, e) => {
    setOperacion(tipo);
    setValor(Number(e.target.value));
  };
  const cinco = operacion === '5%' ? valor : valor / 3;
  const quince = operacion === '15%' ? valor : valor * 3;
  return (
    <div className="seccion-porcentaje">
      <h2>Calculadora de Porcentajes</h2>
      <NumeroInput 
        titulo="Valor al 5%" 
        value={cinco.toFixed(2)} 
        onChange={(e) => manejarCambio('5%', e)} 
      />
      <NumeroInput 
        titulo="Valor al 15%" 
        value={quince.toFixed(2)} 
        onChange={(e) => manejarCambio('15%', e)} 
      />
      <p>Modificado: {operacion}</p>
    </div>
  );
}
// 3. DOMINIO CLIMA (Componente de lógica específica)
function SeccionClima() {
  const [celsius, setCelsius] = useState(0);
  const manejarClima = (e) => setCelsius(Number(e.target.value));
  const fahrenheit = (celsius * 9/5) + 32;
  return (
    <div className="seccion-clima">
      <h2>Conversor de Temperatura</h2>
      <NumeroInput 
        titulo="Grados Celsius (°C)" 
        value={celsius} 
        onChange={manejarClima} 
      />
      <p>Resultado: <strong>{fahrenheit.toFixed(1)} °F</strong></p>
    </div>
  );
}
function NumeroInput({ titulo, value, onChange }) {
  return (
    <div className="input-field">
      <h1>{titulo}</h1>
      <input type="number" value={value} onChange={onChange} />
    </div>
  );
}
```
