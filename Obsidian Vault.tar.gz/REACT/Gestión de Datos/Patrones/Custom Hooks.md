## La Evolución Moderna: 

Con la llegada de React 16.8+ (Hooks), ya no es obligatorio crear dos componentes separados para dividir la lógica de la vista. Ahora la lógica se extrae en funciones llamadas **Custom Hooks**.

- **¿Cómo funciona?:** Toda la lógica del fetch, estados de carga (`loading`) y errores (`error`) se mete dentro de una función propia que empieza con `use` (ej: `useParques()`).
    
- **El cambio clave:** El Hook **no devuelve JSX**, solo devuelve los datos puros limpios y listos para usar.