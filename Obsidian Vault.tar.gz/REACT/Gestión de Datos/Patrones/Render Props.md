```jsx
function Toggle() {
  const [on, setOn] = useState(false);

  // ❌ Esta UI está hardcodeada — no la podés cambiar desde afuera
  return (
    <button onClick={() => setOn(v => !v)}>
      {on ? 'ON' : 'OFF'}
    </button>
  );
}
```

Si querés la misma lógica pero con otra UI, tenés que copiar todo el componente.

---

**Render props resuelve eso**

En vez de renderizar JSX adentro, el componente llama una función que vos le pasaste:

```jsx
function Toggle({ render }) {
  const [on, setOn] = useState(false);
  const toggle = () => setOn(v => !v);
  // En vez de retornar JSX propio,
  // llama la función que recibió como prop
  // y le pasa su estado interno
  return render({ on, toggle }); 
}
```

Ahora vos controlás la UI desde afuera:

```jsx
// Uso 1 — un botón
<Toggle
  render={({ on, toggle }) => (
    <button onClick={toggle}>
      {on ? 'ON' : 'OFF'}
    </button>
  )}
/>

// Uso 2 — misma lógica, UI completamente distinta
<Toggle
  render={({ on, toggle }) => (
    <div
      onClick={toggle}
      style={{ color: on ? 'green' : 'gray' }}
    >
      {on ? '● Activo' : '○ Inactivo'}
    </div>
  )}
/>
```

Los dos usan el mismo `Toggle`. El estado y la lógica viven en `Toggle`. La UI la decide quien lo usa.

---

**Una sola regla para identificarlo**

Si una prop recibe una función que **devuelve JSX**, es render prop. Si recibe una función que **ejecuta lógica** (sin devolver JSX), es callback prop.

```jsx
// Render prop — la función devuelve JSX
render={({ on }) => <span>{on ? 'sí' : 'no'}</span>}

// Callback prop — la función ejecuta algo, no devuelve JSX
onAgregar={(nota) => guardarNota(nota)}
```


