## El "Túnel:"
Esté disponible para **cualquier** componente del árbol, sin tener que pasarlo manualmente por props nivel por nivel.(RESUELVE [[Prop Drilling]])

## ¿Cuándo usarlo? 
- **Usuario logueado** (Nombre, foto, permisos).
- **Tema visual** (Modo oscuro / claro).
- **Idioma** (Español / Inglés).
- **Carrito de compras** (En un e-commerce).

Hoy lo ves en el `main.jsx` de casi toda app: 
- `<QueryClientProvider>` de React Query hace disponible el cache de datos en toda la app.
- `<BrowserRouter>` [[React Router]] de React Router comparte el historial de navegación.
- `<ThemeProvider>` de Material UI distribuye tokens de diseño. Si en tu app hay un `<AlgoProvider>` envolviendo el árbol, es este patrón.

Analogía del mundo real: El tablero eléctrico de un edificio: no pasás cables piso a piso, cada departamento se conecta al panel central.

```jsx
const AuthCtx = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  return (
    <AuthCtx.Provider value={{ user, setUser }}>
      {children}
    </AuthCtx.Provider>
  );
}
// Cualquier componente, sin importar la profundidad:
function Navbar() {
  const { user } = useContext(AuthCtx);
  return <span>Hola, {user?.name}</span>;
}
```

**El patrón correcto es los dos juntos: [[Proveedor (Context API)]] + [[Custom Hooks]] (`useContext`) **
```jsx
// El Provider COMPARTE el estado
function NotasProvider({ children }) {
  const [notas, setNotas] = useState([]);
  const agregarNota = (nota) => setNotas(prev => [...prev, nota]);
  return (
    <ContextoNotas.Provider value={{ notas, agregarNota }}>
      {children}
    </ContextoNotas.Provider>
  );
}
// El custom hook es la INTERFAZ para consumirlo
// No tiene useState propio — accede al estado del Provider
function useNotas() {
  const ctx = useContext(ContextoNotas);
  if (!ctx) throw new Error('useNotas debe usarse dentro de <NotasProvider>');
  return ctx;
}
```

---

**Y el Contenedor siempre sigue siendo componente** porque necesita renderizar JSX. Pero su lógica podría vivir en un hook si fuera compleja:

```jsx
// Si el contenedor tuviera lógica compleja, la extraés a un hook
function useNotasContenedor() {
  const { notas, agregarNota } = useNotas();
  const notasOrdenadas = [...notas].sort(/* algo */);
  const agregarConValidacion = (nota) => {
    if (!nota.titulo.trim()) return;
    agregarNota(nota);
  };
  return { notasOrdenadas, agregarConValidacion };
}

// El componente queda delgado, solo renderiza
function NotasContenedor() {
  const { notasOrdenadas, agregarConValidacion } = useNotasContenedor();
  return (
    <>
      <FormNota onAgregar={agregarConValidacion} />
      <ListaNotas notas={notasOrdenadas} />
    </>
  );
}
```

---

**La excepción donde SÍ podés evitar el Provider** es [[Zustand]] — guarda el estado completamente afuera de React:

```jsx
// Zustand — estado global sin Provider
const useNotasStore = create((set) => ({
  notas: [],
  agregarNota: (nota) => set(state => ({
    notas: [...state.notas, nota]
  })),
}));

// Cualquier componente lo consume directo, sin Provider en ningún lado
function ComponenteA() {
  const { notas } = useNotasStore(); // ✅ comparte estado real
}
function ComponenteB() {
  const { notas } = useNotasStore(); // ✅ el mismo estado
}
```

---

|Necesidad|Solución|
|---|---|
|Estado local a un componente|[[useState]] o [[Custom Hooks]] simple|
|Estado compartido entre componentes|[[Proveedor (Context API)]] + [[Custom Hooks]]|
|Estado global sin Provider|[[Zustand]] ([[Patron Observer]])|