- **[[Proveedor (Context API)]]:** **NO** usa el patrón Observer puro. Cuando el valor de un contexto cambia, React obliga a re-renderizar a **todos** los componentes que estén consumiendo ese contexto, sin importar si usan todo el objeto o solo un numerito.
    
- **[[Zustand]]:** **SÍ** implementa el patrón Observer por fuera del árbol de React. Gracias a esto, logra romper la regla de React de que _"si el padre cambia, los hijos cambian"_, permitiendo que solo se entere el componente exacto que sufrió una modificación en su selector.

### ¿Cómo evita Zustand los re-renders innecesarios?

Zustand usa **Selectores** (`useCartStore(s => s.items.length)`).

Cuando cambias algo en el store, Zustand ejecuta el selector y compara el resultado con el valor anterior usando comparación estricta (`===`).

- Si cambiaste el precio de un producto, pero la _longitud_ del carrito sigue siendo `3`, el componente que solo mira el `.length` **NO se re-renderiza**.
    

> ⚠️ **Nota de rendimiento:** Métodos como `.map()` o `.filter()` siempre crean un array nuevo en memoria. Si un componente extrae el array completo (`s => s.items`), se re-renderizará aunque el contenido sea idéntico. Para solucionarlo, se usa el comparador `shallow` de Zustand: `useCartStore(s => s.items, shallow)`.

---
## ¿Cuándo usar cuál?

|**Criterio**|**[[Proveedor (Context API)]]**|**[[Zustand]]**|
|---|---|---|
|**Frecuencia de Cambio**|Baja / Estática|Alta / Dinámica|
|**Patrón de Diseño**|Proveedor (Service Locator)|Observador (PubSub) puro|
|**Rendimiento**|Re-renderiza en bloque|Re-renderizado quirúrgico (vía selectores)|
|**Casos de uso ideales**|- Cambios de Idioma (I18n)<br><br>  <br><br>- Temas (Dark/Light Mode)<br><br>  <br><br>- Datos de Auth de usuario|- Carritos de compra<br><br>  <br><br>- Filtros de búsqueda complejos<br><br>  <br><br>- Notificaciones / Modales interactivos|
