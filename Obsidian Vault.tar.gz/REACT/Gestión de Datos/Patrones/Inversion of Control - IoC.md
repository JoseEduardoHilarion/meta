A un nivel más general de ingeniería de software, estás aplicando Inversión de Control. En lugar de que el componente hijo controle qué pasa con los datos al hacer submit, **invierte el control** y le delega esa responsabilidad al componente padre (el que lo invocó), pasándole los datos empaquetados.

## A continuación te detallo los nombres técnicos con los que se le conoce a este mismo Patron:

- ### 1. [[Elevar el Estado]] (State Lifting) 

- ### 2. [[Patron Observer]] / Publicador-Suscriptor (Simplificado)
El componente padre "se suscribe" (o le otorga) una función al hijo para que este le _avise_ (`notify`) cuando ocurra un evento (en este caso, cuando se envíe el formulario).