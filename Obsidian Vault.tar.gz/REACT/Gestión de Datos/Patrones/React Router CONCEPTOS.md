**Los tres conceptos que no cambian entre v6, v7 y v8:**

**El mapa mental completo:**

```
React Router (cualquier versión)
│
├── Concepto 1: URL → matching → árbol de componentes
├── Concepto 2: Outlet → ranura donde aparece el hijo
├── Concepto 3: History API → navegación sin recarga
└── Concepto 4: Loaders → datos antes del render (v6.4+)

Lo que cambia entre versiones:
  └── Solo la sintaxis para expresar estos 4 conceptos
```


**1. Matching (Mapeo) — la URL se compara con las rutas definidas**

```
URL actual: /lista/42

¿Coincide con /?          no
¿Coincide con /acceso?    no
¿Coincide con /lista?     sí ✅
¿Coincide con /lista/:id? sí ✅ (id = "42")
```

React Router recorre las rutas definidas y monta las que coinciden. Si hay anidamiento, monta todas las que coinciden en ese nivel.

**2. Outlet — el "hueco" donde se renderiza el hijo**

```jsx
// Layout define dónde va la página activa
function Layout() {
  return (
    <>
      <Navbar />
      <Outlet />   {/* acá aparece Lista, Acceso, o lo que coincida */}
      <Footer />
    </>
  );
}

// Lista define dónde va la subruta activa
function Lista() {
  return (
    <div>
      <ul>...</ul>
      <Outlet />   {/* acá aparece Modal cuando la URL es /lista/42 */}
    </div>
  );
}
```

Cada `<Outlet />` es una ranura. La URL determina qué entra en cada ranura.

**3. History API — navegar sin recargar**

```
Browser nativo:    click en <a href="/lista"> → request al servidor → recarga toda la página
React Router:      click en <Link to="/lista"> → intercepta el click → cambia la URL
                   → React Router hace el matching → monta los componentes nuevos
                   → sin ningún request al servidor
```

---

**Cómo cambia solo la sintaxis entre versiones:**

```jsx
// El CONCEPTO — siempre el mismo:
// "cuando la URL es /lista, mostrá el componente Lista"

// v6 — JSX
<Route path="/lista" element={<Lista />} />

// v7/v8 — objeto
{ path: '/lista', element: <Lista /> }

// v7/v8 — con loader (mismo concepto + datos antes de renderizar)
{ path: '/lista', element: <Lista />, loader: listLoader }
```

---

**Los loaders — el único concepto nuevo que agrega v6.4+**

Antes: los datos se fetcheaban adentro del componente con `useEffect`.  
Con loaders: los datos se fetchean antes de que el componente se monte.

```
Sin loader:   URL cambia → componente monta → useEffect → fetch → datos llegan → re-render
Con loader:   URL cambia → loader fetcha → datos listos → componente monta con datos ya disponibles
```

```jsx
// El loader corre antes del render
async function listLoader() {
  const notas = await fetch('/api/notas').then(r => r.json());
  return notas; // quedan disponibles en el componente
}

// El componente los lee sin useEffect ni loading state
function Lista() {
  const notas = useLoaderData(); // datos ya están acá
  return notas.map(n => <NotaCard key={n.id} {...n} />);
}
```

---

