## 1. Core
Es una librería de manejo de estado global basada en el [[Patron Observer]]. El estado vive en un almacén (store) fuera del árbol de React.

### Truco de Sintaxis: El Retorno Implícito de Objetos
En las funciones flecha, para devolver un objeto directamente sin usar la palabra `return`, se debe envolver entre paréntesis `({ ... })`.
* `create((set) => ({ ... }))` -> Los paréntesis le dicen a JavaScript: *"Esto no es el cuerpo de la función, es el objeto del store que estoy devolviendo"*.

### Analogía con `useState`
El `set` de Zustand funciona igual que el actualizador (*setter*) de `useState`:
1. **Valor directo:** `set({ isOpen: true })` (No importa el pasado).
2. **Estado anterior (Función):** `set(s => ({ items: [...s.items, p] }))` (Depende de lo que había antes). `s` representa el estado actual en ese instante.

---

## 2. Modificaciones Genéricas en Arrays de Objetos
Para modificar un objeto dentro de un array sin mutar el estado original (regla de oro de React), se usa `.map()` combinado con el *Spread Operator* (`...`).

### La Función Genérica Definitiva
En lugar de crear una función para cada propiedad (`updateQuantity`, `updatePrice`), es mejor pasar el `id` y un objeto con los cambios (`updatedFields`):

```javascript
updateItem: (id, updatedFields) => set(s => ({
  items: s.items.map(item => 
    item.id === id 
      ? { ...item, ...updatedFields } // Fusiona lo viejo con los cambios (el último pisa al anterior)
      : item                           // Lo deja intacto
  )
})),
```

**Flexibilidad de JS:** Gracias a esto, puedes enviar un solo campo, varios, o el objeto entero modificado. Todos funcionan:

```jsx
updateItem(1, { quantity: 5 })    
updateItem(1, { price: 25, color: 'azul' })
```

---
EJEMPLO: creás un store con `create()` y cualquier componente en cualquier parte de la app puede suscribirse con el hook del store. 

```jsx
// Store global con Zustand
const useCartStore = create((set) => ({
  items: [], // <-- El estado (la lista de productos)
  
  // Acción para agregar un producto
  add: (p) => set(s => ({ items: [...s.items, p] })),
  
  // Acción para eliminar un producto por su ID
  remove: (id) => set(s => ({
    items: s.items.filter(i => i.id !== id)
  })),
}));
//El contador del carrito:
function CartBadge() {
  const n = useCartStore(s => s.items.length);
  return <span className="badge">{n}</span>;
}
//El botón de agregar
function AddButton({ product }) {
  const add = useCartStore(s => s.add);
  return <button onClick={() => add(product)}>+ Agregar</button>;
}
```

En el mundo de Zustand, el mapa de actores es el siguiente:

- **El Sujeto (Subject):** Es el Store global (`useCartStore`). Él guarda la lista de productos (`items`) y es el único dueño de la verdad.
    
- **Los Observadores (Observers):** Son tus componentes de React (`CartBadge` y `AddButton`) a través de sus funciones selectoras.
    

## La "Variación" Inteligente de Zustand (El Selector)

En el Patron Observer tradicional, cuando el Sujeto cambia, les grita a **todos** sus observadores: _"¡Oigan, cambié, actualícense todos!"_.

Zustand mejora este patrón clásico agregando el concepto de **Selectores** (`s => s.items.length`). Podríamos llamarlo un **"Observer con Filtro"**:

1. **Suscripción (Primera Vez):** Cuando `CartBadge` se monta, el hook le dice a Zustand: _"Anotame en tu lista de interesados, pero ojo, solo me importa el resultado de esta función `s.items.length`"_.
    
2. **Notificación Inteligente (Siguientes Veces):** Cuando agregas un producto, Zustand (el Sujeto) cambia. En lugar de avisarle a todos a ciegas, Zustand recorre su lista de observadores y ejecuta sus filtros en el fondo:
    
    - Al filtro de `CartBadge` antes le daba `0` y ahora le da `1`. **Zustand lo notifica.**
        
    - Al filtro de `AddButton` antes le daba la función `add` y ahora le sigue dando la misma función. **Zustand lo ignora y no lo notifica.**
        


---