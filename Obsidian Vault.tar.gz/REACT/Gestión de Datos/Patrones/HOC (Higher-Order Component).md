Siempre es `conAlgo(Componente) → ComponenteMejorado`. El componente original no sabe que está siendo envuelto.

El HOC más usado hoy con diferencia es **`React.memo`**: recibe tu componente y devuelve una versión que se saltea el re-render si sus props no cambiaron. Fuera de eso los ves en Relay, en el antiguo `connect()` de Redux y en wrappers de autenticación. Los hooks reemplazaron muchos casos de uso, pero para transformaciones estructurales de componentes los HOCs siguen siendo la herramienta exacta.

Usado hoy en

React.memo, Next.js withAuth, Relay, Redux connect()

```JavaScript
// HOC de autenticación
function withAuth(Component) {
  return function Protected(props) {
    const { user } = useContext(AuthCtx);
    if (!user) return <Navigate to="/login" />;
    return <Component {...props} />;
  };
}
const Dashboard = withAuth(DashboardBase);

// El HOC más usado hoy: React.memo
const MetaCard = React.memo(function MetaCard({ meta }) {
  // Solo re-renderiza si cambian sus props
  return <div className="card">{meta.titulo}</div>;  
});

```
---
