[[React Router CONCEPTOS]]

**PROBLEMA:** Tu app tiene una sola URL (`/`). No importa en qué "página" estés, la URL nunca cambia. 

No podés compartir links, no funciona el botón atrás del browser, y si recargás la página volvés al inicio. React Router resuelve todo eso.

**El setup base — va en `main.jsx`**
```jsx
import { BrowserRouter } from 'react-router-dom';

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>   {/* envuelve TODO — es el Provider del router */}
    <App />
  </BrowserRouter>
);
```

---

**Las piezas principales, una por una:**

`Routes` mira la URL actual y renderiza el `Route` que coincida. Solo uno a la vez.

```jsx
import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <Routes>
      <Route path="/"       element={<Home />} />
      <Route path="/notas"  element={<Notas />} />
      <Route path="/perfil" element={<Perfil />} />
      <Route path="*"       element={<NoEncontrado />} /> {/* 404 */}
    </Routes>
  );
}
```


---

**`Link` y `NavLink` — navegación sin recargar la página**

Nunca uses `<a href="...">` en React Router — eso recarga la página entera.

```jsx
import { Link, NavLink } from 'react-router-dom';

function Navbar() {
  return (
    <nav>
      {/* Link — navegación simple */}
      <Link to="/">Home</Link>
      <Link to="/notas">Notas</Link>

      {/* NavLink — igual que Link pero sabe si está activo */}
      <NavLink
        to="/perfil"
        className={({ isActive }) => isActive ? 'activo' : ''}
      >
        Perfil
      </NavLink>
    </nav>
  );
}
```


---

**`useNavigate` — navegación desde código (NO desde un click directo)**

Lo usás cuando la navegación pasa después de algo — un submit, una acción asíncrona, una validación.

```jsx
import { useNavigate } from 'react-router-dom';

function FormLogin() {
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    await login(); // lógica de login
    navigate('/notas'); // redirige cuando termina
  };
}
```


---

**`useParams` — leer valores de la URL**

```jsx
// Definís la ruta con :id
<Route path="/notas/:id" element={<DetalleNota />} />

// En el componente leés el parámetro
import { useParams } from 'react-router-dom';

function DetalleNota() {
  const { id } = useParams();
  // URL: /notas/42  →  id = "42"
  // URL: /notas/7   →  id = "7"
}
```

---

**`Outlet` — rutas anidadas con layout compartido**

Este es el patrón más común en apps reales. Tenés un Layout con Navbar y Footer que se mantiene fijo, y solo el contenido del medio cambia:

```jsx
import { Outlet } from 'react-router-dom';

function Layout() {
  return (
    <>
      <Navbar />        {/* siempre visible */}
      <main>
        <Outlet />      {/* acá aparece Home, Notas, o Perfil */}
      </main>
      <Footer />        {/* siempre visible */}
    </>
  );
}

// En App.jsx — el Layout envuelve todas las rutas
function App() {
  return (
    <Routes>
    {/*Rutas sin una `path` crean nuevos anidamientos para sus hijos, pero no añaden ningún segmento a la URL.*/}
      <Route element={<Layout />}>          
        <Route path="/"       element={<Home />} />
        <Route path="/notas"  element={<Notas />} />
        <Route path="/perfil" element={<Perfil />} />
      </Route>
      <Route path="*" element={<NoEncontrado />} />
    </Routes>
  );
}
```

---

**El mapa completo de lo que viste:**

```
main.jsx
└── BrowserRouter          → provee el contexto del router
    └── App
        └── Routes         → mira la URL actual
            ├── Route /    → muestra <Home />
            ├── Route /notas → muestra <Notas />
            └── Route /perfil → muestra <Perfil />

Hooks disponibles en cualquier componente adentro:
  useNavigate()  → para navegar desde código
  useParams()    → para leer :parametros de la URL
  useLocation()  → para leer la URL completa actual
```

---

[[React Router MEJORAS]]