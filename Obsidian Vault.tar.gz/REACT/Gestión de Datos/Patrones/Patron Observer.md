[[Inversion of Control - IoC]]

Los componentes se suscriben a una fuente de estado EXTERNA y se re-renderizan automáticamente cuando esa fuente cambia, sin ningún Provider en el árbol. La fuente vive completamente fuera de React.

Usado hoy en: [[Zustand]]; Redux useSelector; Jotai; useSyncExternalStore.





