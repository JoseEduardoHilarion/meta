- Capa de datos: **Hook:** Maneja el _Estado Global/API_.
    
- Capa de Conexion: **Contenedor:** Maneja el _Contexto del Componente_.
    
- Capa de Vista: **Presentación:** Maneja los _Píxeles y Estilos_.

```JavaScript
// 1. CAPA DE DATOS: Custom Hook profesional
function useParques() {
    const [parques, setParques] = React.useState([]);
    const [loading, setLoading] = React.useState(true);
    const [error, setError] = React.useState(null);

    React.useEffect(() => {
        // 1. Creamos una instancia del controlador de aborto
        const controller = new AbortController();
        const signal = controller.signal;

        fetch(fetchUrl, { signal }) // 2. Le pasamos la señal al fetch
            .then(res => { if (!res.ok) throw new Error(); return res.json(); })
            .then(data => {
                const conUrls = data.map(p => ({
                    id: p.id,
                    nombre: p.title || "Parque Nacional",
                    imageUrl: `${baseUrl}/highres/${p.id}/1.jpg`
                }));
                setParques(conUrls);
                setLoading(false);
            })
            .catch(err => {
                // 3. Nosotros cancelamos la petición, lo ignoramos de forma segura
                if (err.name === 'AbortError') {
                    console.log('Petición cancelada con éxito.');
                } else {
                    setError("No se pudieron cargar los parques.");
                    setLoading(false);
                }
            });

        // 4. LA FUNCIÓN DE LIMPIEZA (Cleanup)
        // Cuando el componente se desmonta
        return () => {
            controller.abort(); // ¡Decimos a la API que ya no la necesitamos!
        };
    }, []);

    return { parques, loading, error };
}

// 2. CAPA DE CONEXIÓN: Contenedor (Maneja qué pantalla mostrar)
function ContenedorDeParques() {
    const { parques, loading, error } = useParques();

    if (loading) return <div>Cargando increíbles paisajes...</div>;
    if (error) return <div style={{ color: 'red' }}>{error}</div>;

    return <Parques parques={parques} />;
}

// 3. CAPA DE VISTA: Componente tonto (Puro, accesible y testeable)
function Parques({ parques }) {
    return parques.map(parque => (
        <img 
            className="parque-thumb" 
            src={parque.imageUrl} 
            key={parque.id} 
            alt={`Vista panorámica de ${parque.nombre}`} 
        />
    ));
}
```

## **La razón profunda por la que MVC puro no encaja en React:**

MVC nació para aplicaciones donde la Vista y el Modelo son capas separadas en archivos distintos. En React, un componente puede tener las tres cosas al mismo tiempo:

```jsx
function NotasContenedor() {
  // "Model" — el estado
  const [notas, setNotas] = useState([]);

  // "Controller" — la lógica
  const agregarNota = (nota) => setNotas(prev => [...prev, nota]);

  // "View" — el JSX
  return <FormNota onAgregar={agregarNota} />;
}
```

MVC los separa en clases distintas. React los junta en una función y te da herramientas para extraer lo que se vuelve complejo :
- los hooks extraen el modelo
- los contenedores extraen el controller
- los presentacionales son la vista pura

---

**El resumen:**

```
¿MVC en React?

Backend de la app    → MVC puro ✅
Redux                → inspirado en MVC ✅
React puro           → no necesita MVC, usa composición
                       pero los PRINCIPIOS de MVC están ahí:
                       Hook = Model
                       Contenedor = Controller
                       Presentación = View
```