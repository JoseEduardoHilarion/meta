**El patrón más cercano en refactoring.guru es Strategy**

Strategy dice: _"encapsulá un algoritmo en un objeto y hacelo intercambiable"_. Render Props dice lo mismo pero con funciones en vez de objetos.

En GoF con clases:

```js
// Strategy — la "estrategia" de renderizado es un objeto
class BotonUI {
  render(on, toggle) {
    return `<button onclick="${toggle}">${on ? 'ON' : 'OFF'}</button>`;
  }
}

class Toggle {
  constructor(strategy) {
    this.strategy = strategy; // le inyectás la estrategia
  }
  render() {
    return this.strategy.render(this.on, this.toggle);
  }
}
```

En React con Render Props:

```jsx
// La "estrategia" es una función en vez de un objeto
<Toggle
  render={({ on, toggle }) => (   // ← la estrategia
    <button onClick={toggle}>{on ? 'ON' : 'OFF'}</button>
  )}
/>
```

El concepto es idéntico: la lógica (`Toggle`) no sabe nada de la presentación. La presentación es intercambiable desde afuera. La diferencia es solo el paradigma — clases vs funciones.

---

**También tiene algo de Template Method**

Template Method dice: _"definí el esqueleto de un algoritmo y dejá que otros completen los pasos variables"_. `Toggle` define el esqueleto (manejar el estado on/off), y el render prop es el "paso variable" que vos completás — la parte que cambia entre cada uso.

---

**La diferencia clave con el sitio**

Refactoring.guru documenta patrones de 1994 pensados para OOP con herencia. Render Props es un patrón de 2016 que emergió de la realidad funcional de React. No vas a encontrar "Render Props" en ese sitio — pero si entendés Strategy y Template Method de ahí, Render Props te va a resultar inmediatamente familiar porque es la misma idea resuelta con funciones de primera clase en vez de clases.