## ¿Cuándo usarlo?
Cuando el estado tiene **múltiples sub-valores** o cuando la **lógica de actualización es compleja**. Es una alternativa a `useState` para estados que involucran varias transiciones.

> Regla práctica: si te encontrás escribiendo muchos `useState` relacionados entre sí (ej. `isLoading`, `error`, `data`), probablemente `useReducer` sea más claro.

## Las 3 piezas

1. **Estado inicial**: el objeto que representa toda la información.
2. **Reducer**: una función pura `(estado, acción) => nuevoEstado`.
3. **dispatch**: la función que enviás para "pedir" un cambio de estado.

## Ejemplo

```jsx
import { useReducer } from "react";

// 1. Estado inicial
const estadoInicial = { contador: 0, pasos: 1 };

// 2. Reducer: define cómo cambia el estado según la acción
function reducer(estado, accion) {
  switch (accion.type) {
    case "INCREMENTAR":
      return { ...estado, contador: estado.contador + estado.pasos };
    case "DECREMENTAR":
      return { ...estado, contador: estado.contador - estado.pasos };
    case "CAMBIAR_PASOS":
      return { ...estado, pasos: accion.payload };
    case "RESETEAR":
      return estadoInicial;
    default:
      return estado; // Siempre retornar el estado actual si la acción no coincide
  }
}

function Contador() {
  const [estado, dispatch] = useReducer(reducer, estadoInicial);

  return (
    <div>
      <p>Contador: {estado.contador}</p>
      <p>Pasos: {estado.pasos}</p>
      <button onClick={() => dispatch({ type: "INCREMENTAR" })}>+</button>
      <button onClick={() => dispatch({ type: "DECREMENTAR" })}>-</button>
      <input
        type="number"
        value={estado.pasos}
        onChange={(e) =>
          dispatch({ type: "CAMBIAR_PASOS", payload: Number(e.target.value) })
        }
      />
      <button onClick={() => dispatch({ type: "RESETEAR" })}>Reset</button>
    </div>
  );
}
```

## Comparación con useState

| | `useState` | `useReducer` |
|---|---|---|
| **Ideal para** | Estado simple, independiente | Estado complejo o relacionado |
| **Lógica** | Inline en el componente | Centralizada en el reducer |
| **Testing** | Difícil aislar | Fácil: el reducer es una función pura |
| **Legibilidad** | Clara para casos simples | Más clara cuando hay muchas transiciones |

---
