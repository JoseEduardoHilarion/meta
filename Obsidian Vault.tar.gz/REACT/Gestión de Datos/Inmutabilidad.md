**Concepto:** El estado en React es de "solo lectura". Nunca se modifica el objeto o arreglo original.

- **Filosofía:** "No retoques la foto vieja, revela una nueva".
    
- **Beneficio:** Permite que React detecte cambios de forma ultra rápida comparando referencias de memoria.
    
- **Evitar:** `push`, `pop`, `splice` o `sort`, asignaciones directas (`arr[i] = val`).
    
- **Usar:**  `map`, `filter`, `slice`, o el _spread operator_ `[...spread]`

---
