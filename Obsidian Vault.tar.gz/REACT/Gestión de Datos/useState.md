- Datos internos:
	- Mientras que los props vienen “de afuera”, el **state** vive dentro del componente y puede cambiar con el tiempo.
	- Props ≠ State

```jsx
import { useState } from "react";
function Toggle() {
  const [estado, setEstado] = useState(true); // true = ON
  const texto = estado ? "ON" : "OFF";
  return (
    <div>
      <p>Valor actual: {texto}</p>
      <button onClick={() => setEstado(!estado)}>
        Cambiar a {estado ? "OFF" : "ON"}
      </button>
    </div>
  );
}
```

---