## 🔑 Atajos clave (con LSP funcionando)

|Acción|Atajo / Cómo|
|---|---|
|**Ir a la definición**|`F12` o `Ctrl + clic` sobre un componente/función|
|**Ver todas las referencias** (dónde se usa un componente)|`Shift + F12`|
|**Abrir archivo rápido**|`Ctrl + P` y escribe el nombre|
|**Símbolos del archivo actual** (componentes, funciones)|`Ctrl + R`|
|**Símbolos en todo el proyecto**|`Ctrl + Shift + R`|
|**Ver info/tipos al pasar el cursor**|solo coloca el cursor encima (hover)|


## 🧭 Comandos LSP desde la paleta (`Ctrl/Cmd + Shift + P` → escribe "LSP")

Los más útiles para entender código ajeno:

- **LSP: Call Hierarchy** → te muestra **quién llama a esta función/componente** (muy valioso para rastrear flujos)
- **LSP: Rename** → renombrar un símbolo en todo el proyecto de forma segura
- **LSP: Show Diagnostics Panel** → ver todos los errores/avisos del proyecto

## 🗺️ Estrategia recomendada para un proyecto desconocido

1. **Abre la carpeta como proyecto:** `Project → Add Folder to Project` (importante para que la búsqueda global funcione).
2. Empieza por el punto de entrada: `Ctrl + P` → busca `index.tsx` o `main.tsx`.
3. Desde ahí sigue el flujo: `Ctrl + clic` en `<App />` → luego en las rutas/páginas.
4. Cuando encuentres un componente y quieras saber **dónde se usa** → `Shift + F12`.
5. Cuando quieras saber **quién llama a una función** → `LSP: Call Hierarchy`.
6. Complementa con el diagrama desde consola:

bash

```bash
   npx madge --image deps.svg --extensions jsx,js src/
```

## ⚠️ Si algo falla

Si al abrir un `.tsx` no funciona F12 o no aparece el hover:

- Ve a `Tools → LSP → Language Servers` y verifica que **typescript** esté activo.
- O desde la paleta ejecuta **`LSP: Troubleshoot Server`** para ver el problema.

Con esto, Sublime Text te sirve perfectamente para explorar y entender proyectos React sin cambiar de editor. 👌