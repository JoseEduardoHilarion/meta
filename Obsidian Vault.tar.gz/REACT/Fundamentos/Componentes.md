Es una función de JavaScript que:
1. Recibe **Props** (entradas).
2. Retorna **[[JSX]]** (lo que se ve).

> [!TIP] Regla de Oro
> Si un componente tiene más de 200 líneas, es hora de aplicar [[Elevar el Estado]] o dividirlo en componentes más pequeños.