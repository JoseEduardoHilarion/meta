### Estrategia de Diagnóstico CSS (Selector vs DOM)

#### 1. La Regla de Oro del ==ESPACIO== en Selectores

El espacio en CSS no es estético, es un **operador lógico**:

- **SIN ESPACIO (`.clase1.clase2`)**: Operador **AND** (Y).
    
    - _Significado:_ Busca UN elemento que tenga ambas clases al mismo tiempo.
        
    - _Uso común:_ Modificadores de estado (ej. `.acordeon__wrapper--abierto`).
        
- **CON ESPACIO (`.clase1 .clase2`)**: Operador **DESCENDANT** (Hijo/Descendiente).
    
    - _Significado:_ Busca un elemento con la `clase2` que esté **dentro** de un elemento con la `clase1`.
        
    - _Uso común:_ Estilizar elementos internos (ej. `.acordeon .titulo`).
        

#### 2. Checklist de Supervivencia (Protocolo de Error)

Cuando un cambio de estado (clic, hover, etc.) no se refleja visualmente, sigue este orden:

1. **Inspeccionar el DOM (F12):** * ¿El HTML tiene las clases que yo espero? (¿React/JS hizo su trabajo?).
    
    - _Si la clase NO está:_ El error es de **Lógica/JavaScript**.
        
2. **Verificar el Selector en CSS:**
    
    - ¿La regla en el archivo `.css` coincide exactamente con la jerarquía del HTML?
        
    - **Punto Crítico:** ¿Puse un espacio de más que convirtió un "Modificador" en un "Hijo"?
        
3. **Validar la Cascada:**
    
    - ¿Hay otra regla más abajo que está pisando mi estilo?
        

#### 3. Ejemplo Visual para Memoria Rápida

- **HTML:** `<div class="btn activo">`
    
- **CSS Correcto:** `.btn.activo { color: red; }` (La persona es botón y está activo).
    
- **CSS Incorrecto:** `.btn .activo { color: red; }` (Busca algo activo _dentro_ del botón).
    

---