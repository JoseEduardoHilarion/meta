✅ Funciona — solo en Sass/SCSS

```css
/* npm install -D sass  →  renombrar a .scss */
.formulario-login {
  display: flex;

  &__input {        /* ✅ Sass expande → .formulario-login__input */
    padding: 10px;

    &--error {      /* ✅ Sass expande → .formulario-login__input--error */
      border: 1px solid red;
    }
  }
}
```

✅ Funciona — CSS nativo con nesting

```css
/* & sí funciona para hijos HTML, pseudo-clases y pseudo-elementos */
.formulario-login {
  display: flex;
}

.formulario-login__input {   /* selector completo, fuera del padre */
  padding: 10px;

  & input { ... }            /* ✅ anida elemento HTML */
  &:hover { ... }            /* ✅ anida pseudo-clase */
  &::placeholder { ... }     /* ✅ anida pseudo-elemento */
}

.formulario-login__input--error {   /* selector completo */
  border: 1px solid red;
}

```

### Regla clave: el & solo puede referenciar, no concatenar texto

  &:hover      → ✅  .formulario-login:hover
  
  & h2         → ✅  .formulario-login h2
  
  &__input     → ❌  el navegador no concatena strings
  
  &--error     → ❌  igual

---
