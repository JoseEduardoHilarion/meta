# La Simulación del Mundo

Su trabajo es mantener un "Mundo en Memoria" sincronizado con el "Mundo Real".

## 1. El Disparador (The Trigger)

Cuando usas un `setEstado`, no estás cambiando una variable, estás **disparando una alarma**.
- Esta alarma le dice a React: _"Algo en la lógica interna cambió, volvé a calcular cómo debería verse el mundo"_.    

## 2. Ejecución del Cuerpo de la Función (Render Phase)

React vuelve a llamar a la función del componente de arriba a abajo ".JSX".

- **Memoria Persistente (Hooks):** Aunque la función se ejecuta de cero, React "le sopla" a los Hooks ([[useState]], `useRef, ect`) los valores que ya tenía guardados. No los resetea, los **recupera**.
    
- **Nuevos Punteros:** Todas las variables `const` y funciones flecha comunes se crean de nuevo en la RAM del navegador (nuevas direcciones de memoria).
    

## 3. El Mundo Virtual (Virtual DOM)

Al llegar al `return`, la función entrega un **"Racimo de Objetos"**.

- Este es el **Virtual DOM NUEVO**: una representación ligera, puramente de datos, de cómo debería estar la pantalla en este instante.
    
- Es como un plano de arquitectura hecho de código JS.
    

## 4. La Reconciliación (El Espejo)

React ahora tiene **dos mundos en memoria**: el que estaba hace un segundo (Viejo) y el que acaba de calcular (NUEVO).

- **Comparación de Punteros:** Gracias a la **inmutabilidad**, React no pierde tiempo leyendo todo. Compara las direcciones base: `¿0x123 === 0x456?`.
    
- Si la dirección cambió, sabe que ese "racimo" tiene cambios y entra a mirar qué hay adentro.
    
- **Las Keys:** Aquí es donde el "DNI" (la `key`) brilla. Si los elementos se movieron de lugar, React los reconoce por su DNI y no tiene que destruirlos y crearlos de nuevo.
- _Diffing_. Es el que decide si el "racimo de objetos" nuevo es lo suficientemente distinto para tocar el DOM Real
    

## 5. Actualización del Mundo Real (Commit Phase)

Una vez que React identificó exactamente qué píxel o qué letra cambió en su simulación:

- Va al **DOM Real** (el navegador) y aplica la **cirugía mínima**.
    
- Si en tu simulación cambiaste el color de un botón, React solo toca la propiedad `.style` de ese botón en el navegador. No toca nada más.    

> [!NOTE] Nota técnica para el desarrollador
> **React es Declarativo:** Tú solo le dices "cómo quieres que se vea el mundo" en el `return`. React se encarga de toda la "fontanería" (comparar punteros, gestionar memorias y actualizar el HTML).


---
