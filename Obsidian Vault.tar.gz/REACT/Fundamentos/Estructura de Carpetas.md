Plaintext

```
src/
├── assets/          # Imágenes, iconos, estilos globales (CSS)
├── components/      # Pedacitos reutilizables (Botones, Navbar, Footer, Tarjetas)
├── pages/           # Componentes que representan una "ruta" completa
│   ├── Home.jsx     # Lo que se ve en "/"
│   ├── Contacto.jsx # Lo que se ve en "/contacto"
│   └── Login.jsx    # Lo que se ve en "/login"
├── routes/          # (Opcional) Para guardar la configuración de rutas
├── App.jsx          # El "corazón" donde unes las rutas y las páginas
└── main.jsx         # El punto de entrada que renderiza todo
```

---