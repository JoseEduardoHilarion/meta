Es una extensión de sintaxis que mezcla **HTML** y **JavaScript**. No es HTML real: el compilador (Babel/Vite) lo transforma en llamadas a `React.createElement()`.

```jsx
// Lo que escribís:
const elemento = <h1 className="titulo">Hola, {nombre}</h1>;

// Lo que ejecuta el navegador (equivalente):
const elemento = React.createElement("h1", { className: "titulo" }, "Hola, " + nombre);
```

## Reglas clave
1. **Un solo elemento raíz**: cada componente debe retornar un único elemento padre. Si no querés agregar un `<div>` extra, usá un **Fragment**: `<>...</>`.
2. **`className` en vez de `class`**: `class` es una palabra reservada en JS.
3. **Expresiones entre llaves `{}`**: podés insertar cualquier expresión JS (variables, ternarios, llamadas a funciones). ==NO PODES== poner `if/else` directo, pero sí el operador ternario.
4. **Atributos en camelCase**: `onclick` → `onClick`, `onchange` → `onChange`.
5. **Las etiquetas vacías deben cerrarse**: `<input />`, `<img />`.

## Condicionales en JSX
```jsx
// ✅ Operador ternario
{isLoggedIn ? <Dashboard /> : <Login />}

// ✅ Short-circuit (&&) para renderizado condicional
{isAdmin && <PanelAdmin />}

// ❌ No podés usar if directamente dentro del return
```

## Listas y Keys
```jsx
const frutas = ["Manzana", "Banana", "Naranja"];

return (
  <ul>
    {frutas.map((fruta, index) => (
      <li key={index}>{fruta}</li>  // La key ayuda a React en la reconciliación
    ))}
  </ul>
);
```

> [!TIP] Preferí `key` con IDs únicos (ej. `key={fruta.id}`) en vez de `index` cuando el orden de la lista puede cambiar.

---
