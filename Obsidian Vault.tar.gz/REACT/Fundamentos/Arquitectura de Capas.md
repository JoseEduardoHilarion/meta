### Concepto

Las capas definen un **orden de mando** que el navegador respeta por encima de la especificidad técnica. Es el "Contrato de Prioridad".

### El Contrato (Declaración en `index.css`)

CSS

```
@layer base, utilidades, componentes;
```

### Jerarquía de Poder

1. **Capa Componentes:** El estilo final (el color de mi botón hoy).
    
2. **Capa Utilidades:** El motor (sombras neumórficas, layouts).
    
3. **Capa Base:** Resets y valores por defecto.
    

> [!TIP] Si algo está en la capa **componentes**, siempre le ganará a lo que esté en **utilidades**, aunque uses selectores más complejos en la base.

---


