- ## Componentes

```jsx
import React, { Component } from 'react';
class Saludo extends Component {
  render() {
    return <h1>¡Hola, mundo!</h1>;
  }
}
export default Saludo;
```

- ## Props 
```jsx
class TarjetaUsuario extends Component {
  render() {
    return (
      <div>
        <h2>{this.props.nombre}</h2>
        <p>Edad: {this.props.edad}</p>
      </div>
    );
  }
}
// Uso:
<TarjetaUsuario nombre="Ana" edad={28} />
```

- ## State 
El **estado** es la memoria del componente. Cuando cambia, React re-renderiza la UI automáticamente.
```jsx
class Contador extends Component {
  constructor(props) {
    super(props);
    this.state = { likes: 0 };  // Estado inicial
  }
  incrementar = () => {
    this.setState({ likes: this.state.likes + 1 });
  }
  render() {
    return (
      <div>
        <p>❤️ {this.state.likes} likes</p>
        <button onClick={this.incrementar}>Me gusta</button>
      </div>
    );
  }
}
```

- ## Ciclo de vida
Los componentes "nacen", se "actualizan" y "mueren". Podés ejecutar código en cada etapa.
```jsx
class ListaUsuarios extends Component {
  constructor(props) {
    super(props);
    this.state = { usuarios: [] };
  }
  componentDidMount() {  // Se ejecuta cuando el componente aparece en pantalla
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(data => this.setState({ usuarios: data }));
  }
  render() {
    return (
      <ul>
        {this.state.usuarios.map(u => (
          <li key={u.id}>{u.name}</li>
        ))}
      </ul>
    );
  }
}
```

---

- ## 📊 Clases vs Funciones

|Concepto|Clases|Funciones|
|---|---|---|
|Estado|`this.state` / `this.setState`|`useState`|
|Montar|`componentDidMount`|`useEffect(() => {}, [])`|
|Actualizar|`componentDidUpdate`|`useEffect(() => {}, [dep])`|
|Desmontar|`componentWillUnmount`|`useEffect(() => { return () => {} }, [])`|
|Código|Más verboso|Más conciso|
|Uso actual|Legacy / mantenimiento|✅ Estándar moderno|

