 ### El concepto "Mata-Miedos"

Las variables no solo guardan datos, permiten que la **Capa 2** consuma un valor que la **Capa 3** define.

### Estructura de Trabajo

- **Definición (Capa 1/3):** `--bg-actual: #e0e0e0;` (El papelito en la puerta).
    
- **Consumo (Capa 2):** `background-color: var(--bg-actual);` (El obrero que lee el papelito).
    

### Ventaja para el Hardware (Q6600)

El navegador no tiene que recalcular todo el árbol de estilos, solo actualiza el valor de la variable en memoria y repinta el área afectada. Es **eficiencia pura**.

---