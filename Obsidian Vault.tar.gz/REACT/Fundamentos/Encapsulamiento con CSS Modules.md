### ¿Qué es?

Es una herramienta de construcción (Vite) que transforma nombres de clases simples en **hashes únicos**.

### Comparativa: Simulación vs Realidad

|Técnica|Implementación|Tipo|
|---|---|---|
|**Shadow DOM**|Nativo del Navegador|Estándar|
|**CSS Modules**|Hashes de Clase (`.clase_x5z9`)|Simulación (Vite)|

Exportar a Hojas de cálculo

### Regla de Oro para el "Laburo"

1. **NO usar `composes`:** Es un invento que genera dependencia.
    
2. **Usar Composición en React:** 
```jsx 
// Unir clases manualmente o con arrays 
const clases = [utils.raised, styles.miComponente].join(' ');
```
   

---
 
