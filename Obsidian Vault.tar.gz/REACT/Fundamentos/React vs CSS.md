### El Reencuentro:

> [!IMPORTANT] **Mayúsculas y Minúsculas**
> 
> - **React:** Componentes empiezan con **Mayúscula** (`<Formulario />`).
>     
> - **CSS:** Clases siempre en **minúscula** (`.formulario`).
>     
> - **Match:** > `<div className="bloque-nombre__elemento--estado">`
>