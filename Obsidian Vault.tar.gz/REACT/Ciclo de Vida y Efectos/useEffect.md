- Con `[]` → solo al montar y desmontar.
- Con `[dependencias]` → al montar y cada vez que cambian esas dependencias.
- Sin dependencias → en cada render. 

Es la herramienta principal para manejar efectos secundarios. Ejemplo:
```jsx
import { useState, useEffect } from "react";
function Ejemplo() {
  const [contador, setContador] = useState(0);
  // Se ejecuta al montar y cada vez que cambia "contador"
  useEffect(() => {
    console.log("El contador cambió:", contador);
    // Función de limpieza:se ejecuta al desmontar el componente.
    return () => {
      console.log("Componente desmontado");
    };
  }, [contador]);//se dispara cada vez que el contador cambia.
  return (
    <div>
      <p>Valor: {contador}</p>
      <button onClick={() => setContador(contador + 1)}>Sumar</button>
    </div>
  );
}
```

---