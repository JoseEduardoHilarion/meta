Parecido a [[useEffect]], pero se ejecuta _antes_ de que el navegador pinte la pantalla.**Si necesitás controlar el DOM antes de que se pinte**

```jsx
import { useState, useEffect, useLayoutEffect } from "react";
function DemoLayout() {
  const [contador, setContador] = useState(0);
  useEffect(() => {
    console.log("useEffect → después de pintar en pantalla");
  }, [contador]);
  useLayoutEffect(() => {
    console.log("useLayoutEffect → antes de pintar en pantalla");
  }, [contador]);
  return (
    <div>
      <p>Contador: {contador}</p>
      <button onClick={() => setContador(contador + 1)}>Sumar</button>
    </div>
  );
}
```

---
