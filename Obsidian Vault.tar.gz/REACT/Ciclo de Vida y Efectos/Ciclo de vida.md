### 📘 Ciclo de vida del componente
- **Montaje** → aparece por primera vez en pantalla.    
- **Actualización** → cada vez que cambian props o estado, React vuelve a ejecutar la función del componente y actualiza lo necesario en el DOM. Aquí el componente sigue “vivo”, no se destruye.    
- **Desmontaje** → ahí sí el componente se elimina del DOM, y es el momento en que realmente “muere”.    
### 📘 Ciclo de vida de los efectos
Cada [[useEffect]] vive dentro del ciclo del componente:
- Se ejecuta al montar (si corresponde).    
- Se vuelve a ejecutar cuando cambian sus dependencias.    
- Su `return` se ejecuta como **limpieza** antes de que el efecto vuelva a correr o cuando el componente se desmonta.    

> [!NOTE] 👉 Entonces:
> - Montaje y actualización son fases distintas pero forman parte de la vida activa del componente.
> - El desmontaje coincide con la destrucción del componente.
> 
> El `return` de un [[useEffect]] no significa que el componente entero se destruya, sino que ese efecto está limpiando lo que hizo.

### Manejo directo en el render
>- **Si solo querés mostrar cosas según estado**, lo resolvés directamente en el JSX, usas [[useState]].
>- **Si querés engancharte al ciclo de vida** (inicio, actualizaciones, final), usás [[useEffect]].    
>- **Si necesitás controlar el DOM antes de que se pinte**, usás [[useLayoutEffect]].    
---
