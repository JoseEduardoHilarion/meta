export function metaReglas(datos, campo = null) {
  const errores = {};
  const reglas = {
    detalles: () => {
      if (!datos.detalles?.trim())
        errores.detalles = 'La descripción no puede estar vacía.';
      else errores.detalles = '';
    },
    periodo: () => {
      if (!datos.periodo?.trim())
        errores.periodo = 'Debe seleccionar un período';
      else errores.periodo = '';
    },
    eventos: () => {
      if (!datos.eventos?.trim())
        errores.eventos = 'La frecuencia no puede estar vacia.';
      else if (Number(datos.eventos) <= 0)
        errores.eventos = 'La frecuencia debe ser mayor a 0.';
      else errores.eventos = '';
    },
    meta: () => {
      if (!datos.meta?.trim()) errores.meta = 'La Meta no puede estar vacia.';
      else if (Number(datos.meta) <= 0)
        errores.meta = 'El objetivo total debe ser mayor a 0.';
      else errores.meta = '';
    },
    completado: () => {
      if (!datos.completado?.trim())
        errores.completado = 'Completado no puede estar vacia.';
      else if (Number(datos.completado) < 0)
        errores.completado = 'El progreso no puede ser un número negativo.';
      else errores.completado = '';
    },
  };
  const relacionMetaCompletado = () => {
    const completadoNum = Number(datos.completado);
    const metaNum = Number(datos.meta);
    if (completadoNum > metaNum)
      errores.completado = `No podés haber completado (${completadoNum}) más de tu objetivo total (${metaNum}).`;
  };

  if (!campo) {
    Object.values(reglas).forEach((regla) => regla());

    if (!errores.meta && !errores.completado) relacionMetaCompletado();
  } else if (reglas[campo]) {
    reglas[campo]();
    if (
      (campo === 'meta' || campo === 'completado') &&
      !errores.meta &&
      !errores.completado
    )
      relacionMetaCompletado();
  }
  return {
    esValido: Object.values(errores).every((valor) => !valor),
    errores,
  };
}
