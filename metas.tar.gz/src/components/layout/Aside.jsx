import { useNavigate, useLocation } from 'react-router';
import { Item } from '../ui/Item';
import { Icono } from '../ui/Icono';
import { cn } from '../../utils';

export const Aside = ({ esMovil, cerrarMenu }) => {
	const navigate = useNavigate();
	const location = useLocation(); // Obtenemos la ruta actual del navegador

	// Verificamos si la ruta actual coincide exactamente
	const esActivo = (ruta) => (location.pathname === ruta ? 'item-activo' : '');

	const handleLinkClick = (pagina) => {
		if (esMovil && cerrarMenu) {
			cerrarMenu();
		}
		navigate(pagina);
	};
	return (
		<div className={cn('neumo-convex')}>
			<Item
				// Si es activo, le sumamos una clase CSS para que se vea seleccionado/hundido
				className={cn('fw-bold', esActivo('/Lista'))}
				onClick={() => handleLinkClick('/Lista')}
			>
				<Icono>
					<img src="/img/lista.svg" alt="Lista de Metas" />
				</Icono>
				Lista de Metas
			</Item>

			<Item
				clickable
				className={cn('fw-bold', esActivo('/Nueva'))}
				onClick={() => handleLinkClick('/Nueva')}
			>
				<Icono>
					<img src="/img/nueva.svg" alt="Nueva Meta" />
				</Icono>
				Nueva Meta
			</Item>
		</div>
	);
};
